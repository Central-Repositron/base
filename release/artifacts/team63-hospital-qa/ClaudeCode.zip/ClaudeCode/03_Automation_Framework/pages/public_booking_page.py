from playwright.sync_api import Page
import config


class PublicBookingPage:
    """
    The anonymous, public-facing appointment booking form at
    /health_plix/book. Uses plain HTML form inputs (not the Odoo backend
    widget structure), so selectors here are simple id-based locators.
    """

    def __init__(self, page: Page):
        self.page = page

    def goto(self):
        self.page.goto(config.PUBLIC_BOOKING_URL)
        self.page.wait_for_load_state("load")
        self.page.locator("#doctor_id").wait_for(state="visible", timeout=config.DEFAULT_TIMEOUT_MS)

    def select_doctor(self, label_substring: str):
        select = self.page.locator("#doctor_id")
        select.select_option(label=self._match_option_label(select, label_substring))

    def _match_option_label(self, select_locator, substring: str) -> str:
        options = select_locator.locator("option").all_inner_texts()
        for opt in options:
            if substring in opt:
                return opt
        raise ValueError(f"No doctor option containing '{substring}' found in {options}")

    def fill_patient_info(self, name: str, email: str, phone: str,
                           gender: str | None = None, dob: str | None = None,
                           address: str | None = None):
        self.page.locator("#patient_name").fill(name)
        self.page.locator("#patient_email").fill(email)
        self.page.locator("#patient_phone").fill(phone)
        if gender:
            # The radio <input> is visually hidden behind a styled pill
            # label (for="gender_male" etc.) — click the label, not the
            # (not-visible) input, so Playwright's actionability check passes.
            self.page.locator(f'label[for="gender_{gender.lower()}"]').click()
        if dob:
            self.page.locator("#patient_dob").fill(dob)  # YYYY-MM-DD
        if address:
            self.page.locator("#patient_address").fill(address)

    def fill_date_time(self, date_iso: str, time_hhmm: str, reason: str = ""):
        """date_iso: 'YYYY-MM-DD' (native <input type=date> format)."""
        self.page.locator("#appointment_date").fill(date_iso)
        self.page.locator("#appointment_time").fill(time_hhmm)
        if reason:
            self.page.locator("#appointment_notes").fill(reason)

    def submit(self):
        self.page.get_by_role("button", name="Confirm Appointment").click()
        self.page.wait_for_load_state("load")
        # The form submits via fetch/AJAX and swaps content in place rather
        # than always doing a hard navigation, so give the async
        # success/error state time to render before anything checks it.
        self.page.wait_for_timeout(2000)

    def is_confirmation_shown(self) -> bool:
        try:
            self.page.get_by_text("Appointment Confirmed!").wait_for(state="visible", timeout=4000)
            return True
        except Exception:
            return False

    def error_text(self) -> str | None:
        """Inline booking error, e.g. 'This time slot is not available...'"""
        candidates = self.page.locator(".alert-danger, .scc-form-error, .text-danger")
        if candidates.count() > 0:
            return candidates.first.inner_text().strip()
        return None

    def confirmation_ref(self) -> str:
        text = self.page.get_by_text("Confirmation:").inner_text()
        return text.replace("Confirmation:", "").strip()

    def validation_message_for(self, field_id: str) -> str:
        """Native HTML5 constraint-validation message for a required field."""
        return self.page.locator(f"#{field_id}").evaluate("el => el.validationMessage")
