from playwright.sync_api import Page
import config
from pages.base_page import BasePage


class AppointmentPage(BasePage):
    def __init__(self, page: Page):
        super().__init__(page)

    def goto_list(self):
        self.page.goto(config.action_url("appointments"))
        self.wait_ready()

    def create(self, doctor: str, patient: str, date: str, time: str, fee: str):
        """
        date: string in the site's display format, e.g. '01/25/2027' (MM/DD/YYYY)
              or a relative-safe absolute date string you've already computed.
        time: 'HH:MM' 24h.
        fee:  numeric string, may be negative to reproduce BUG-01.
        """
        self.click_new()
        self.select_many2one("doctor_id", doctor)
        self.select_many2one("patient_id", patient)
        self.fill_char("appointment_date", date)
        self.page.keyboard.press("Escape")
        self.fill_char("appointment_time", time)
        self.fill_char("cost", str(fee))
        self.page.locator("body").click(position={"x": 5, "y": 5})
        self.save_if_needed()
        self.wait_ready()

    def appointment_no(self) -> str:
        return self.breadcrumb_record_name()

    def cost_value(self) -> str:
        return self.get_input_value("cost")

    def confirm(self):
        self.click_button("Confirm")
        # The statusbar re-renders asynchronously after the RPC completes;
        # wait for "Mark as Done" (only present once Confirmed) rather than
        # trusting a generic wait_ready() + an immediate status() read,
        # which can race the click and observe stale "Draft" state.
        self.page.get_by_role("button", name="Mark as Done").wait_for(
            state="visible", timeout=config.DEFAULT_TIMEOUT_MS
        )

    def cancel(self):
        self.click_button("Cancel")
        self.wait_ready()

    def mark_as_done(self):
        self.click_button("Mark as Done")
        self.wait_ready()

    def create_billing(self):
        self.click_button("Create Billing")
        self.wait_ready()

    def status(self) -> str:
        return self.current_status()
