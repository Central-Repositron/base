from playwright.sync_api import Page
import config
from pages.base_page import BasePage


class BillingPage(BasePage):
    def __init__(self, page: Page):
        super().__init__(page)

    def goto_list(self):
        self.page.goto(config.action_url("billing"))
        self.wait_ready()

    def bill_no(self) -> str:
        return self.breadcrumb_record_name()

    def total_amount(self) -> str:
        """Total Amount is a read-only computed field (rendered as plain
        text, not an <input>), so it must be read via inner_text(), not
        get_input_value() (which would hang waiting for a non-existent
        input element)."""
        raw = self.get_text("total_amount")
        return raw.replace(",", "").replace("₹", "").strip()

    def status(self) -> str:
        return self.current_status()

    def create_invoice(self):
        self.click_button("Create Invoice")
        self.wait_ready()

    def list_total_footer(self) -> str:
        """Aggregate total shown at the bottom of the Billing list view."""
        return self.page.locator(".o_list_footer, tfoot").first.inner_text().strip()
