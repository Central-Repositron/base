from playwright.sync_api import Page
import config
from pages.base_page import BasePage


class DashboardPage(BasePage):
    """
    The Hospital Operations Dashboard — uses the site's own CSS hooks
    (.hp-stat-card / .hp-stat-title / .hp-stat-value / .hp-card-name),
    confirmed present in the live DOM, rather than role/text locators,
    since these are stable custom classes purpose-built for this page.
    """

    def __init__(self, page: Page):
        super().__init__(page)

    def goto(self):
        self.page.goto(config.DASHBOARD_URL)
        self.wait_ready()

    def kpi_titles(self) -> list[str]:
        return [t.strip() for t in self.page.locator(".hp-stat-title").all_inner_texts()]

    def kpi_value(self, title: str) -> str:
        card_title = self.page.locator(".hp-stat-title", has_text=title).first
        card = card_title.locator("xpath=ancestor::*[contains(@class,'hp-stat-card')][1]")
        return card.locator(".hp-stat-value").first.inner_text().strip()

    def quick_access_names(self) -> list[str]:
        return [t.strip() for t in self.page.locator(".hp-card-name").all_inner_texts()]

    def top_nav_link_visible(self, name: str) -> bool:
        return self.page.get_by_role("link", name=name, exact=True).first.is_visible()
