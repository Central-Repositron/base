from playwright.sync_api import Page
import config


class LoginPage:
    def __init__(self, page: Page):
        self.page = page

    def goto(self):
        self.page.goto(config.LOGIN_URL)

    def login(self, username: str = config.USERNAME, password: str = config.PASSWORD):
        self.page.locator("#login").fill(username)
        self.page.locator("#password").fill(password)
        self.page.locator('button[type="submit"]').first.click()
        # Odoo's backend keeps a long-poll connection open, so
        # "networkidle" never fires here — wait for navigation instead.
        self.page.wait_for_load_state("load")

    def error_message(self) -> str | None:
        alert = self.page.locator(".alert")
        if alert.count() > 0:
            return alert.first.inner_text().strip()
        return None
