from playwright.sync_api import Page
import config
from pages.base_page import BasePage


class PatientPage(BasePage):
    def __init__(self, page: Page):
        super().__init__(page)

    def goto_list(self):
        self.page.goto(config.action_url("patients"))
        self.wait_ready()

    def create(self, name: str, phone: str = "", email: str = "", address: str = ""):
        self.click_new()
        self.fill_char("name", name)
        if phone:
            self.fill_char("phone", phone)
        if email:
            self.fill_char("email", email)
        if address:
            self.fill_textarea("address", address)
        self.save_if_needed()
        self.wait_ready()

    def uhid(self) -> str:
        """The Patient UHID / record name shown in the breadcrumb (e.g. PAT/00007)."""
        return self.breadcrumb_record_name()

    def open_by_name(self, name: str):
        self.goto_list()
        self.page.locator(".o_list_table tbody tr").filter(has_text=name).first.click()
        self.wait_ready()
