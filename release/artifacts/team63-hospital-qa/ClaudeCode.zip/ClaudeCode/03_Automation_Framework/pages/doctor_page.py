from playwright.sync_api import Page
import config
from pages.base_page import BasePage


class DoctorPage(BasePage):
    def __init__(self, page: Page):
        super().__init__(page)

    def goto_list(self):
        self.page.goto(config.action_url("doctors"))
        self.wait_ready()

    def create(self, name: str, specialization: str = "", experience: str = "",
               phone: str = "", email: str = "", address: str = ""):
        self.click_new()
        self.fill_char("name", name)
        if specialization:
            self.fill_char("specialization", specialization)
        if experience != "":
            self.fill_char("experience", str(experience))
        if phone:
            self.fill_char("phone", phone)
        if email:
            self.fill_char("email", email)
        if address:
            self.fill_textarea("address", address)
        self.save_if_needed()
        self.wait_ready()

    def list_row_values(self, row_text: str) -> dict:
        row = self.page.locator(".o_list_table tbody tr").filter(has_text=row_text).first
        cells = row.locator("td")
        return {"count": cells.count()}
