"""
Base Page Object with helpers shared by all Odoo backend pages.

Odoo's web client renders every form field inside a container:
    <div class="o_field_widget" name="<technical_field_name>"> ... </div>
Targeting `.o_field_widget[name="X"]` is the standard, resilient way to
locate a field in Playwright/Selenium Odoo automation because it keys off
the technical field name (stable) rather than layout/CSS classes (fragile).
"""
from __future__ import annotations
from playwright.sync_api import Page
import config


class BasePage:
    def __init__(self, page: Page):
        self.page = page

    # ---------- generic Odoo form helpers ----------

    def field(self, name: str):
        """Locator for a field's widget container."""
        return self.page.locator(f'.o_field_widget[name="{name}"]').first

    def fill_char(self, name: str, value: str):
        """Fill a simple text/number/date input field by technical name."""
        loc = self.field(name).locator("input").first
        loc.click()
        loc.fill("")
        loc.fill(value)

    def fill_textarea(self, name: str, value: str):
        loc = self.field(name).locator("textarea").first
        loc.click()
        loc.fill(value)

    def get_input_value(self, name: str) -> str:
        loc = self.field(name).locator("input").first
        return loc.input_value()

    def get_text(self, name: str) -> str:
        return self.field(name).inner_text().strip()

    def get_date_value(self, name: str) -> str:
        """
        Odoo's date/daterange widget renders as an <input> only while being
        actively edited; once saved it collapses to a
        <button data-tooltip="MM/DD/YYYY" value="MM/DD/YYYY">Jan 1, 2024</button>
        for display. get_input_value() would hang waiting for a nonexistent
        <input> on a saved record, so read the button's raw `value`
        attribute instead (falling back to an <input> if one is present,
        e.g. mid-edit).
        """
        widget = self.field(name)
        input_loc = widget.locator("input").first
        if input_loc.count() > 0:
            return input_loc.input_value()
        button_loc = widget.locator("button").first
        return button_loc.get_attribute("value") or button_loc.get_attribute("data-tooltip") or ""

    def select_many2one(self, name: str, search_text: str, option_text: str | None = None):
        """
        Type into a many2one field (e.g. Doctor, Patient) and click the
        matching autocomplete suggestion.
        """
        loc = self.field(name).locator("input").first
        loc.click()
        loc.fill("")
        loc.type(search_text, delay=30)
        dropdown_item = self.page.locator(
            ".o-autocomplete--dropdown-menu li, .ui-autocomplete li"
        ).filter(has_text=option_text or search_text).first
        dropdown_item.wait_for(state="visible", timeout=config.DEFAULT_TIMEOUT_MS)
        dropdown_item.click()

    def click_button(self, text: str, exact: bool = True):
        self.page.get_by_role("button", name=text, exact=exact).first.click()

    def click_new(self):
        self.click_button("New")
        self.wait_ready()

    def save_if_needed(self, attempts: int = 3):
        """
        Odoo 17/18 autosaves on field blur / navigation in most cases, but a
        manual save affordance (cloud icon) can still appear after edits.
        Click it if present; otherwise this is a no-op.

        On a `.../new` form, Odoo assigns the real record id (URL changes
        from `.../new` to `.../<id>`) once the save round-trip completes, so
        that's used as the definitive success signal — a single click can
        occasionally land before the previous field's onchange RPC has
        settled, so this retries rather than trusting one click blindly.
        """
        was_new = self.page.url.rstrip("/").endswith("/new")
        save_btn = self.page.locator(
            'button.o_form_button_save, .o_form_status_indicator_buttons button[title*="Save"]'
        ).first

        for _ in range(attempts):
            try:
                save_btn.wait_for(state="visible", timeout=2000)
            except Exception:
                break  # no pending changes / already saved
            try:
                save_btn.click()
            except Exception:
                pass
            self.page.wait_for_timeout(700)
            self.raise_if_error_dialog()
            if not was_new or not self.page.url.rstrip("/").endswith("/new"):
                break

    def raise_if_error_dialog(self):
        """Surface Odoo's blocking 'Validation Error' modal as a clear
        assertion failure instead of letting callers silently retry/timeout
        against it (e.g. server-side uniqueness constraints)."""
        dialog = self.page.locator(".modal-title", has_text="Validation Error")
        if dialog.count() > 0 and dialog.first.is_visible():
            body = self.page.locator(".modal-body").first.inner_text().strip()
            self.page.locator(".modal .btn", has_text="Close").first.click()
            raise AssertionError(f"Odoo Validation Error: {body}")

    def discard_if_needed(self):
        discard_btn = self.page.locator(
            'button.o_form_button_cancel, .o_form_status_indicator_buttons button[title*="Discard"]'
        ).first
        try:
            if discard_btn.is_visible(timeout=1000):
                discard_btn.click()
        except Exception:
            pass

    def breadcrumb_record_name(self) -> str:
        return self.page.locator(".o_breadcrumb .active").last.inner_text().strip()

    def current_status(self) -> str:
        """Return the label of the currently-active statusbar stage, e.g. 'Confirmed'."""
        current = self.page.locator(
            ".o_statusbar_status button.o_arrow_button_current, "
            ".o_statusbar_status .o_arrow_button_current"
        ).first
        return current.inner_text().strip()

    def wait_ready(self):
        """
        Odoo's backend keeps a long-poll ("bus") connection open, so
        `networkidle` never resolves there. Wait for the DOM load event plus
        the main content container, with a short settle buffer instead.
        """
        self.page.wait_for_load_state("load")
        try:
            self.page.locator(".o_content, .o_form_view, .o_list_view").first.wait_for(
                state="visible", timeout=config.DEFAULT_TIMEOUT_MS
            )
        except Exception:
            pass
        self.page.wait_for_timeout(400)
