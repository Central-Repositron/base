import pytest
from playwright.sync_api import sync_playwright
import config
from pages.login_page import LoginPage
from api_client import OdooAPIClient


@pytest.fixture(scope="session")
def playwright_instance():
    with sync_playwright() as p:
        yield p


@pytest.fixture(scope="session")
def browser(playwright_instance):
    browser = playwright_instance.chromium.launch(
        headless=config.HEADLESS, slow_mo=config.SLOW_MO_MS
    )
    yield browser
    browser.close()


@pytest.fixture
def context(browser):
    ctx = browser.new_context(viewport={"width": 1400, "height": 900})
    ctx.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
    yield ctx
    ctx.close()


@pytest.fixture
def page(context):
    pg = context.new_page()
    yield pg
    pg.close()


@pytest.fixture
def logged_in_page(page):
    """A page with an authenticated backend session, ready at the Dashboard."""
    login = LoginPage(page)
    login.goto()
    login.login()
    page.wait_for_url("**/odoo/**", timeout=config.DEFAULT_TIMEOUT_MS)
    return page


@pytest.fixture
def public_page(page):
    """A page with no session — for testing the anonymous public booking form."""
    return page


@pytest.fixture
def fresh_doctor_name(browser):
    """
    Creates a brand-new Doctor via an authenticated context and returns its
    name, for tests that book against the public form. Using a freshly
    created doctor (rather than an arbitrary existing one) guarantees no
    prior appointment already occupies the date/time this test will try —
    the app enforces one-slot-per-doctor-per-time, so reusing a doctor
    across runs risks a "slot unavailable" false result instead of
    genuinely exercising date/time validation.
    """
    from pages.doctor_page import DoctorPage
    from utils import unique_suffix

    ctx = browser.new_context()
    ctx.set_default_timeout(config.DEFAULT_TIMEOUT_MS)
    pg = ctx.new_page()
    login = LoginPage(pg)
    login.goto()
    login.login()
    pg.wait_for_url("**/odoo/**", timeout=config.DEFAULT_TIMEOUT_MS)

    doc = DoctorPage(pg)
    doc.goto_list()
    name = f"QA - Dr. Public {unique_suffix()}"
    doc.create(name=name)

    ctx.close()
    return name


@pytest.fixture
def api_client():
    """Authenticated Odoo JSON-RPC client — talks to /web/dataset/call_kw
    directly, no browser involved. Used to prove UI-observed defects are
    server-side model gaps, not just missing client-side JS validation."""
    client = OdooAPIClient()
    client.authenticate()
    return client
