# Automation Framework — Shivansh Cancer Center (Odoo Hospital App)

Playwright (Python) + pytest, Page Object Model. Built and verified against the live QA instance at https://team63.qaaglobal.com during this engagement.

## What this covers

- Backend login (`tests/test_login.py`)
- Doctor CRUD + field-validation regressions (`tests/test_doctor.py`)
- Patient creation (`tests/test_patient.py`)
- Appointment creation + past-date regression (`tests/test_appointment.py`)
- **Flagship P0 regression**: negative fee flowing Appointment → Confirm → Billing (`tests/test_billing_negative_fee.py`)
- Public booking form happy path + validation-gap regressions (`tests/test_public_booking.py`)
- Dashboard KPI/nav smoke + a real KPI-vs-actual-data integrity check (`tests/test_dashboard.py`)
- **Direct API-layer regressions** (`tests/test_api_direct_validation.py`, `api_client.py`) — hits Odoo's JSON-RPC `/web/dataset/call_kw` with zero browser involved, proving whether a UI-observed defect is a missing client-side check or a genuine server-side model gap, plus an unauthenticated-access control check and an information-disclosure check on error responses

Each test file's docstring references the Test Case ID(s) it automates from [`../02_Test_Cases_and_Data.md`](../02_Test_Cases_and_Data.md) (and, for the presentation-formatted versions, [`../05_Reporting_Pack/test-cases/test-cases.csv`](../05_Reporting_Pack/test-cases/test-cases.csv)).

## Why some tests are marked `xfail(strict=True)`

Several tests encode the **correct/expected** behavior (e.g. "a negative fee must be rejected") rather than the app's current buggy behavior. They are marked `@pytest.mark.xfail(reason="BUG-xx: ...", strict=True)` and will show as **XFAIL** (expected failure) as long as the underlying defect (see `../04_Bugs_and_Enhancements.md`) is open. This is deliberate:

- The suite documents *intended* behavior, not just current behavior — a fresh reader can `grep xfail` to see every open defect with a live, runnable reproduction.
- `strict=True` means that if a developer fixes the bug, the test starts **passing**, which pytest reports as **XPASS** and — because of `strict=True` — turns into a **hard failure** of the run. That failure is the signal to remove the `xfail` marker and close the regression. Nothing can "silently" fix itself and go unnoticed.

## Setup

```bash
cd 03_Automation_Framework
python -m pip install -r requirements.txt
python -m playwright install chromium
```

## Configuration

Defaults to the shared QA instance and the credentials provided for this engagement (`config.py`). Override via environment variables for CI or a different environment:

```bash
set QA_BASE_URL=https://team63.qaaglobal.com
set QA_USERNAME=team63
set QA_PASSWORD=********
set QA_HEADLESS=1
```

## Running

```bash
# Full suite
python -m pytest

# Only P0 tests
python -m pytest -m p0

# Only the known-defect regression tests (all expected to XFAIL until fixed)
python -m pytest -m regression

# A single file, with browser visible for debugging
set QA_HEADLESS=0
python -m pytest tests/test_billing_negative_fee.py -v
```

An HTML report is written to `reports/report.html` on every run (`pytest-html`, self-contained).

## Design notes

- **Page Object Model** (`pages/`): one class per screen/form. `pages/base_page.py` centralizes the Odoo-specific plumbing — locating fields via `.o_field_widget[name="..."]` (the technical field name, which is stable across UI redesigns), selecting many2one values from the autocomplete dropdown, and Odoo's autosave-on-navigate behavior.
- **Real technical field/model names**, not guesses: these were extracted live from the running app via `odoo.__WOWL_DEBUG__` and DOM inspection during exploration (see field/model map in `../01_Test_Strategy.md`), not assumed from typical Odoo conventions. E.g. `healthplix.doctor`, `healthplix.appointment` (fields `doctor_id`, `appointment_date`, `appointment_time`, `cost`, ...), `healthplix.billing` (`total_amount`, ...).
- **Public booking page object** (`pages/public_booking_page.py`) targets plain HTML `id` selectors (`#patient_name`, `#appointment_date`, etc.) since that form is a standard website form, not an Odoo backend widget tree.
- **Test data isolation**: this is a *shared, non-resettable* QA database (see Test Strategy §4.3) — every record created by the suite is prefixed `"QA - "` and suffixed with a timestamp (`utils.unique_suffix()`) so runs don't collide and test data is easy to identify/clean up later. Tests do not delete their own data (no delete/archive flow was in scope this pass); a periodic manual or scripted cleanup of `QA - *` records is recommended.
- **The negative-fee E2E regression stops at Billing**, not Invoice — manual testing during this engagement confirmed the defect propagates one step further into a real Odoo Accounting draft Customer Invoice, but that step is deliberately not automated to avoid creating throwaway draft invoices in Accounting on every CI run.

## Lessons learned: `xfail` can mask the wrong failure

While extending this suite, `--runxfail` (forces xfail tests to run for real and report their actual outcome) surfaced three page-object bugs that had been silently hiding behind `xfail(strict=True)` — each test still correctly showed **XFAIL** (because *something* failed), but not always for the reason the test claimed:

1. **`BillingPage.total_amount()`** read the Billing "Total Amount" field via `get_input_value()`, assuming it was an editable `<input>`. It's actually a **read-only computed field** rendered as plain text — the locator waited the full 30s timeout for an `<input>` that will never exist, then that timeout (not the intended assertion) is what made the test XFAIL.
2. **`AppointmentPage.confirm()`** clicked "Confirm" and immediately moved on; the statusbar re-renders asynchronously, so a `status()` check right after could observe a stale "Draft" — fixed by waiting for the "Mark as Done" button (only present once Confirmed) instead of guessing a delay.
3. **`BasePage.get_input_value()`** on `appointment_date` after save: Odoo's date widget is an `<input>` only while being actively edited; once saved it collapses to a `<button value="MM/DD/YYYY">Jan 1, 2024</button>` for display. Reading it post-save needs the new `get_date_value()` helper, which checks for an input first and falls back to reading the button's `value` attribute.

None of these were application defects — they were automation bugs that happened to still produce the "correct" XFAIL outcome by accident (a timeout is still a failure). They were only caught by deliberately forcing `--runxfail` and inspecting the *actual* traceback/assertion message for each xfail test, not just trusting the green-looking XFAIL status. **Takeaway for anyone extending this suite:** when a new `xfail` test is added, run it once with `--runxfail` and confirm the failure message is the one you wrote, not a timeout or an unrelated exception — otherwise `strict=True`'s safety net (catching a fix via XPASS) can't be trusted either, since it was never observing the right failure in the first place.

## Extending the suite

Not yet automated (see `02_Test_Cases_and_Data.md` "Not Run" rows) — good next additions:
- Prescription medicine-line quantity validation (TC-RX-02)
- Duplicate-patient detection by phone/email (TC-PAT-07 / TC-PUB-07)
- Billing → Invoice → payment lifecycle (TC-BILL-03/04)
- IPD Registration creation (TC-IPD-02)

## CI (suggested, not wired up in this exercise)

```yaml
# .github/workflows/tests.yml (example)
on: [push, pull_request]
jobs:
  e2e:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.12' }
      - run: pip install -r 03_Automation_Framework/requirements.txt
      - run: python -m playwright install --with-deps chromium
      - run: python -m pytest 03_Automation_Framework -m "p0 or p1"
        env:
          QA_USERNAME: ${{ secrets.QA_USERNAME }}
          QA_PASSWORD: ${{ secrets.QA_PASSWORD }}
```
