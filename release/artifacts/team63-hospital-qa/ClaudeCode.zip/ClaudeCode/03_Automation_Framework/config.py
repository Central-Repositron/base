"""
Central configuration for the automation framework.

Credentials default to the shared QA instance credentials provided for this
engagement. For any real/CI use, override via environment variables instead
of editing this file:

    setx QA_BASE_URL "https://team63.qaaglobal.com"
    setx QA_USERNAME "team63"
    setx QA_PASSWORD "..."
"""
import os

BASE_URL = os.environ.get("QA_BASE_URL", "https://team63.qaaglobal.com")
USERNAME = os.environ.get("QA_USERNAME", "team63")
PASSWORD = os.environ.get("QA_PASSWORD", "DLVxepJau1")

LOGIN_URL = f"{BASE_URL}/web/login"
DASHBOARD_URL = f"{BASE_URL}/odoo/action-372"
PUBLIC_BOOKING_URL = f"{BASE_URL}/health_plix/book"

# Known Odoo action IDs / models discovered during exploration (see
# 01_Test_Strategy.md). Navigating directly to an action URL is faster and
# more robust than clicking through menus.
ACTIONS = {
    "dashboard": 372,
    "patients": 374,
    "doctors": 375,
    "appointments": 376,
    "prescriptions": 377,
    "billing": 383,
}

def action_url(key: str) -> str:
    return f"{BASE_URL}/odoo/action-{ACTIONS[key]}"

HEADLESS = os.environ.get("QA_HEADLESS", "1") != "0"
SLOW_MO_MS = int(os.environ.get("QA_SLOWMO", "0"))
DEFAULT_TIMEOUT_MS = 30000

# Where regression tests save proof evidence (screenshots, raw API
# responses) for the presentation/reporting pack.
EVIDENCE_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "05_Reporting_Pack", "evidence",
)
EVIDENCE_DIR = os.path.join(EVIDENCE_ROOT, "screenshots")
EVIDENCE_API_DIR = os.path.join(EVIDENCE_ROOT, "api")
os.makedirs(EVIDENCE_DIR, exist_ok=True)
os.makedirs(EVIDENCE_API_DIR, exist_ok=True)
