"""
Minimal Odoo JSON-RPC client, used to test the API layer directly —
bypassing the browser UI entirely. This is what proves a validation gap
found in the UI (e.g. BUG-01, BUG-02) lives in the server-side model, not
just in missing client-side JavaScript: if a raw call_kw request with no
JS involved still succeeds, no amount of front-end validation would have
been a complete fix.

Odoo's web client itself talks to the server this same way — this is not
an undocumented/hidden endpoint, it's the standard JSON-RPC interface at
POST /web/dataset/call_kw used by every Odoo web session.
"""
from __future__ import annotations
import re
import requests
import config


class OdooAPIClient:
    def __init__(self, base_url: str = config.BASE_URL):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self._request_id = 0

    def _rpc(self, endpoint: str, params: dict, timeout: int = 20) -> dict:
        self._request_id += 1
        payload = {"jsonrpc": "2.0", "method": "call", "id": self._request_id, "params": params}
        resp = self.session.post(f"{self.base_url}{endpoint}", json=payload, timeout=timeout)
        resp.raise_for_status()
        return resp.json()

    def authenticate(self, login: str = config.USERNAME, password: str = config.PASSWORD) -> None:
        """
        Logs in via the standard /web/login form POST (same flow the browser
        uses) rather than the JSON-RPC /web/session/authenticate method —
        the latter requires an explicit database name that isn't known/
        exposed for this instance, while /web/login auto-detects it
        server-side. Establishes a session cookie on self.session that
        subsequent call_kw requests will use.
        """
        login_page = self.session.get(f"{self.base_url}/web/login", timeout=20)
        match = re.search(r'name="csrf_token" value="([^"]+)"', login_page.text)
        if not match:
            raise RuntimeError("Could not find csrf_token on the login page")
        resp = self.session.post(
            f"{self.base_url}/web/login",
            data={"login": login, "password": password, "csrf_token": match.group(1)},
            timeout=20,
        )
        if "session_id" not in self.session.cookies.get_dict() or "/web/login" in resp.url:
            raise RuntimeError(f"Authentication failed — still on login page: {resp.url}")

    def call_kw(self, model: str, method: str, args: list, kwargs: dict | None = None,
                use_session: bool = True) -> dict:
        """Raw call_kw. If use_session is False, sends the request with no
        session cookie (a fresh, unauthenticated request context) to test
        access control independent of this client's logged-in session."""
        sess = self.session if use_session else requests.Session()
        payload = {
            "jsonrpc": "2.0", "method": "call", "id": 0,
            "params": {"model": model, "method": method, "args": args, "kwargs": kwargs or {}},
        }
        resp = sess.post(f"{self.base_url}/web/dataset/call_kw", json=payload, timeout=20)
        return resp.json()

    def create(self, model: str, values: dict) -> dict:
        return self.call_kw(model, "create", [values])

    def read(self, model: str, ids: list, fields: list) -> dict:
        return self.call_kw(model, "read", [ids, fields])
