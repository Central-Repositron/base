"""
API-layer regression suite — hits Odoo's JSON-RPC /web/dataset/call_kw
directly via api_client, with zero browser/JS involved.

Purpose: for every UI-observed validation gap (BUG-01, BUG-02), prove
whether the gap is client-side (JS never ran a check) or server-side (the
model itself has no constraint). A raw call_kw request exercises exactly
the same code path any API consumer would — a mobile app, an integration,
or a stolen session token used outside the browser — so if it succeeds
here, no front-end fix alone can ever close the hole.

Also covers BUG-13: whether error responses leak internal server detail
(file paths, stack traces) to callers, including unauthenticated ones.
"""
import datetime
import json
import os
import pytest
import config
from api_client import OdooAPIClient
from utils import unique_suffix


def _fresh_doctor_id(client: OdooAPIClient) -> int:
    """A brand-new doctor via the API, so date/fee tests aren't masked by
    the (legitimate) doctor/slot double-booking constraint colliding with
    another test's data."""
    result = client.create("healthplix.doctor", {"name": f"API QA Doctor {unique_suffix()}"})
    assert "result" in result, f"Doctor setup failed: {result}"
    return result["result"]


@pytest.mark.p0
@pytest.mark.smoke
@pytest.mark.api
def test_unauthenticated_call_kw_is_rejected(api_client):
    """Positive control: the JSON-RPC endpoint must not serve unauthenticated
    requests. (This one is expected to PASS — access control does work.)"""
    result = api_client.call_kw(
        "healthplix.patient", "search_read", [[], ["name"]], {"limit": 1}, use_session=False
    )
    assert "error" in result, "Expected an unauthenticated call_kw request to be rejected"
    assert result["error"]["data"]["name"] == "odoo.http.SessionExpiredException"


@pytest.mark.p0
@pytest.mark.regression
@pytest.mark.api
@pytest.mark.xfail(
    reason="BUG-01 (Critical): healthplix.appointment.create() accepts a negative cost via direct API call, "
           "with no browser/JS involved — the gap is in the model, not the UI",
    strict=True,
)
def test_api_negative_fee_bypasses_model_validation(api_client):
    doctor_id = _fresh_doctor_id(api_client)
    future_date = (datetime.date.today() + datetime.timedelta(days=30)).isoformat()

    result = api_client.create("healthplix.appointment", {
        "doctor_id": doctor_id,
        "appointment_date": future_date,
        "appointment_time": 9.0,
        "cost": -750.0,
    })
    assert "result" in result, f"Setup failed unexpectedly: {result}"
    appointment_id = result["result"]

    read_result = api_client.read("healthplix.appointment", [appointment_id], ["cost"])
    with open(os.path.join(config.EVIDENCE_API_DIR, "BUG-01_api_negative_fee_create_and_read.json"), "w") as f:
        json.dump({"create_response": result, "read_response": read_result}, f, indent=2)

    saved_cost = read_result["result"][0]["cost"]
    assert saved_cost >= 0, (
        f"Expected the model to reject/floor a negative cost, but appointment {appointment_id} "
        f"was created via direct API with cost={saved_cost}"
    )


@pytest.mark.p0
@pytest.mark.regression
@pytest.mark.api
@pytest.mark.xfail(
    reason="BUG-02 (High): healthplix.appointment.create() accepts a past appointment_date via direct API call — "
           "no _check_valid_date-style constraint exists in the model",
    strict=True,
)
def test_api_past_date_bypasses_model_validation(api_client):
    doctor_id = _fresh_doctor_id(api_client)
    past_date = "2019-05-05"

    result = api_client.create("healthplix.appointment", {
        "doctor_id": doctor_id,
        "appointment_date": past_date,
        "appointment_time": 10.0,
        "cost": 500.0,
    })
    assert "result" in result, f"Setup failed unexpectedly: {result}"
    appointment_id = result["result"]

    read_result = api_client.read("healthplix.appointment", [appointment_id], ["appointment_date"])
    with open(os.path.join(config.EVIDENCE_API_DIR, "BUG-02_api_past_date_create_and_read.json"), "w") as f:
        json.dump({"create_response": result, "read_response": read_result}, f, indent=2)

    saved_date = datetime.date.fromisoformat(read_result["result"][0]["appointment_date"])
    assert saved_date >= datetime.date.today(), (
        f"Expected the model to reject a past appointment_date, but appointment {appointment_id} "
        f"was created via direct API dated {saved_date}"
    )


@pytest.mark.p2
@pytest.mark.regression
@pytest.mark.api
@pytest.mark.xfail(
    reason="BUG-13 (Medium): JSON-RPC error responses leak a full server-side Python traceback "
           "(internal file paths, addon name, ORM internals), including to unauthenticated callers",
    strict=True,
)
def test_api_error_response_does_not_leak_traceback(api_client):
    # Force a real, legitimate validation error (double-booking the same
    # doctor/slot twice) so we're inspecting a genuine error response, not
    # a contrived one.
    doctor_id = _fresh_doctor_id(api_client)
    future_date = (datetime.date.today() + datetime.timedelta(days=45)).isoformat()
    values = {"doctor_id": doctor_id, "appointment_date": future_date, "appointment_time": 11.0, "cost": 100.0}

    first = api_client.create("healthplix.appointment", values)
    assert "result" in first, f"Setup failed unexpectedly: {first}"

    second = api_client.create("healthplix.appointment", values)  # deliberately colliding slot
    assert "error" in second, "Expected the double-booking constraint to reject the second request"

    with open(os.path.join(config.EVIDENCE_API_DIR, "BUG-13_traceback_leak_response.json"), "w") as f:
        json.dump(second, f, indent=2)

    debug_blob = second["error"].get("data", {}).get("debug", "")
    assert "/opt/odoo" not in debug_blob and "Traceback" not in debug_blob, (
        "Expected a clean error message with no internal server paths/traceback, but the response "
        f"leaked server internals: {debug_blob[:200]}..."
    )
