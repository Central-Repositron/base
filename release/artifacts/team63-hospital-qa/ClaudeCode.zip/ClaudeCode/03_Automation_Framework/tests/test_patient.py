"""Covers TC-PAT-02 from 02_Test_Cases_and_Data.md"""
import pytest
from pages.patient_page import PatientPage
from utils import unique_suffix


@pytest.mark.p0
def test_create_patient_with_valid_data(logged_in_page):
    pat = PatientPage(logged_in_page)
    pat.goto_list()
    name = f"QA - Patient {unique_suffix()}"
    pat.create(
        name=name,
        phone="9123456780",
        email=f"qa.{unique_suffix()}@shivansh-test.com",
        address="Example City, Example State, 000000",
    )
    assert pat.breadcrumb_record_name() == name
    uhid = pat.uhid()
    # Odoo backend record still shows the patient name in the breadcrumb;
    # the UHID is visible as the page <h1> field, not the breadcrumb, so we
    # just sanity-check a record was actually created and is addressable.
    assert uhid
