"""Covers TC-DOC-01 through TC-DOC-04 from 02_Test_Cases_and_Data.md"""
import pytest
from pages.doctor_page import DoctorPage
from utils import unique_suffix


@pytest.mark.p0
def test_create_doctor_with_valid_data(logged_in_page):
    doc = DoctorPage(logged_in_page)
    doc.goto_list()
    suffix = unique_suffix()
    name = f"QA - Dr. Valid {suffix}"
    doc.create(
        name=name,
        specialization="Medical Oncology",
        experience="12",
        phone="9876543210",
        email=f"qa.doctor.{suffix}@shivansh-test.com",
    )
    assert doc.breadcrumb_record_name() == name


@pytest.mark.p1
@pytest.mark.regression
@pytest.mark.xfail(reason="BUG-03: Experience (Years) accepts negative values with no validation", strict=True)
def test_doctor_experience_rejects_negative_value(logged_in_page):
    doc = DoctorPage(logged_in_page)
    doc.goto_list()
    name = f"QA - Dr. NegExp {unique_suffix()}"
    doc.create(name=name, experience="-5")
    saved_value = doc.get_input_value("experience")
    assert float(saved_value) >= 0, (
        f"Expected negative experience to be rejected, but it saved as {saved_value!r}"
    )


@pytest.mark.p1
@pytest.mark.regression
@pytest.mark.xfail(reason="BUG-04: Phone field accepts non-numeric text with no format validation", strict=True)
def test_doctor_phone_rejects_non_numeric(logged_in_page):
    doc = DoctorPage(logged_in_page)
    doc.goto_list()
    name = f"QA - Dr. BadPhone {unique_suffix()}"
    doc.create(name=name, phone="abcd123")
    saved_value = doc.get_input_value("phone")
    assert saved_value.isdigit() or saved_value == "", (
        f"Expected non-numeric phone to be rejected, but it saved as {saved_value!r}"
    )


@pytest.mark.p1
@pytest.mark.regression
@pytest.mark.xfail(reason="BUG-05: Email field accepts syntactically invalid text with no format validation", strict=True)
def test_doctor_email_rejects_invalid_format(logged_in_page):
    doc = DoctorPage(logged_in_page)
    doc.goto_list()
    suffix = unique_suffix()
    name = f"QA - Dr. BadEmail {suffix}"
    doc.create(name=name, email=f"not-an-email-{suffix}")  # unique per run, still invalid format
    saved_value = doc.get_input_value("email")
    assert "@" in saved_value and "." in saved_value.split("@")[-1], (
        f"Expected invalid email to be rejected, but it saved as {saved_value!r}"
    )
