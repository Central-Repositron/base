"""Covers TC-APT-01 and TC-APT-03 from 02_Test_Cases_and_Data.md"""
import datetime
import pytest
from pages.doctor_page import DoctorPage
from pages.patient_page import PatientPage
from pages.appointment_page import AppointmentPage
from utils import unique_suffix, future_date_str


@pytest.fixture
def doctor_and_patient(logged_in_page):
    suffix = unique_suffix()
    doc = DoctorPage(logged_in_page)
    doc.goto_list()
    doctor_name = f"QA - Dr. Appt {suffix}"
    doc.create(name=doctor_name)

    pat = PatientPage(logged_in_page)
    pat.goto_list()
    patient_name = f"QA - Patient Appt {suffix}"
    pat.create(name=patient_name, phone="9123456780")

    return doctor_name, patient_name


@pytest.mark.p0
def test_create_appointment_with_valid_future_date(logged_in_page, doctor_and_patient):
    doctor_name, patient_name = doctor_and_patient
    appt = AppointmentPage(logged_in_page)
    appt.goto_list()
    appt.create(
        doctor=doctor_name,
        patient=patient_name,
        date=future_date_str(5),
        time="10:30",
        fee="500.00",
    )
    assert appt.appointment_no().startswith("APT/")
    assert appt.cost_value() in ("500.00", "500.0", "500")


@pytest.mark.p0
@pytest.mark.regression
@pytest.mark.xfail(reason="BUG-02: Appointment Date accepts past dates with no validation", strict=True)
def test_appointment_date_rejects_past_date(logged_in_page, doctor_and_patient):
    doctor_name, patient_name = doctor_and_patient
    appt = AppointmentPage(logged_in_page)
    appt.goto_list()
    past_date = "01/01/2024"
    appt.create(
        doctor=doctor_name,
        patient=patient_name,
        date=past_date,
        time="10:00",
        fee="100.00",
    )
    saved_date = appt.get_date_value("appointment_date")
    parsed = datetime.datetime.strptime(saved_date, "%m/%d/%Y").date()
    assert parsed >= datetime.date.today(), (
        f"Expected a past appointment date to be rejected, but it saved as {saved_date!r}"
    )
