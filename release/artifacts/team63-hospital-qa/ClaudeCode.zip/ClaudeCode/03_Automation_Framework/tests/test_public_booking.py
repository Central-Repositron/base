"""Covers TC-PUB-01, TC-PUB-03, TC-PUB-04, TC-PUB-05 from 02_Test_Cases_and_Data.md"""
import os
import datetime
import pytest
import config
from pages.public_booking_page import PublicBookingPage
from utils import unique_suffix, unique_past_date_iso, unique_time_str


def _future_iso_date(days: int = 5) -> str:
    return (datetime.date.today() + datetime.timedelta(days=days)).isoformat()


@pytest.mark.p0
@pytest.mark.smoke
def test_public_booking_happy_path(public_page, fresh_doctor_name):
    form = PublicBookingPage(public_page)
    form.goto()
    form.select_doctor(fresh_doctor_name)
    form.fill_patient_info(
        name=f"QA Public {unique_suffix()}",
        email=f"qa.public.{unique_suffix()}@shivansh-test.com",
        phone="9999999999",
        gender="male",
    )
    form.fill_date_time(_future_iso_date(5), "11:00", reason="Automated QA booking")
    form.submit()
    assert form.is_confirmation_shown(), f"Booking was not confirmed. Inline error (if any): {form.error_text()}"
    assert form.confirmation_ref().startswith("APT/")


@pytest.mark.p0
@pytest.mark.regression
@pytest.mark.xfail(reason="BUG-02: public booking form accepts a past appointment date", strict=True)
def test_public_booking_rejects_past_date(public_page, fresh_doctor_name):
    form = PublicBookingPage(public_page)
    form.goto()
    form.select_doctor(fresh_doctor_name)
    form.fill_patient_info(
        name=f"QA PastDate {unique_suffix()}",
        email=f"qa.pastdate.{unique_suffix()}@shivansh-test.com",
        phone="9999999999",
    )
    # A fresh doctor (see fresh_doctor_name) has no existing bookings, so a
    # rejection here can only be due to the date being in the past — not a
    # same-slot conflict with an earlier test run.
    form.fill_date_time(unique_past_date_iso(), "10:00")
    form.submit()
    public_page.screenshot(path=os.path.join(config.EVIDENCE_DIR, "BUG-02_public_booking_past_date_confirmed.png"))
    assert not form.is_confirmation_shown(), (
        "Expected the booking to be rejected for a past date, but it was confirmed"
    )


@pytest.mark.p0
@pytest.mark.regression
@pytest.mark.xfail(reason="BUG-02: public booking form accepts a time outside stated OPD hours", strict=True)
def test_public_booking_rejects_out_of_hours_time(public_page, fresh_doctor_name):
    form = PublicBookingPage(public_page)
    form.goto()
    form.select_doctor(fresh_doctor_name)
    form.fill_patient_info(
        name=f"QA OutOfHours {unique_suffix()}",
        email=f"qa.outofhours.{unique_suffix()}@shivansh-test.com",
        phone="9999999999",
    )
    # Site states OPD Hours: Mon-Sat 9am-6pm, Sun 10am-2pm. A fresh doctor
    # + a random future date + an early-hours time isolates "outside OPD
    # hours" as the only plausible rejection reason.
    form.fill_date_time(_future_iso_date(5), unique_time_str())
    form.submit()
    assert not form.is_confirmation_shown(), (
        "Expected an out-of-hours booking to be rejected, but it was confirmed"
    )


@pytest.mark.p2
@pytest.mark.regression
@pytest.mark.xfail(reason="BUG-06: Mobile Number field has no max-length validation", strict=True)
def test_public_booking_mobile_number_has_length_limit(public_page, fresh_doctor_name):
    form = PublicBookingPage(public_page)
    form.goto()
    form.select_doctor(fresh_doctor_name)
    overlong_number = "9" * 20
    form.fill_patient_info(
        name=f"QA LongMobile {unique_suffix()}",
        email=f"qa.longmobile.{unique_suffix()}@shivansh-test.com",
        phone=overlong_number,
    )
    saved = public_page.locator("#patient_phone").input_value()
    assert len(saved) <= 15, (
        f"Expected Mobile Number to be capped at a reasonable length, but accepted {len(saved)} digits"
    )
