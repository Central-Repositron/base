"""
Dashboard smoke + KPI-data-integrity tests.

The visibility checks (KPI cards render, nav/quick-access links present)
are cheap smoke coverage. The genuinely high-value case here is
test_total_patients_kpi_matches_actual_patient_count, which cross-checks
the displayed KPI number against the real record count via the API —
a cosmetic "the card is visible" check (as far as could be told from the
competing PostQode pack, which only asserted visibility) would never catch
a dashboard silently drifting out of sync with the data it's summarizing.
"""
import re
import pytest
from pages.dashboard_page import DashboardPage

EXPECTED_KPI_TITLES = {
    "Total Patients", "OPD Appointments", "Pending Lab Tests", "Paid Revenue", "Active Doctors",
}
EXPECTED_QUICK_ACCESS = {
    "Patients", "Doctors", "Prescriptions", "Lab Reports", "IPD Details",
    "Appointments", "Billing", "Ward Management", "Bed Management",
}


@pytest.mark.p0
@pytest.mark.smoke
def test_dashboard_kpi_cards_render_with_parseable_values(logged_in_page):
    dash = DashboardPage(logged_in_page)
    dash.goto()
    # .hp-stat-title is styled with CSS text-transform: uppercase, so
    # Playwright's inner_text() (rendered/visual text) comes back upper-case
    # even though the underlying DOM text is Title Case — compare
    # case-insensitively rather than depending on a CSS styling detail.
    titles = {t.upper() for t in dash.kpi_titles()}
    expected_upper = {t.upper() for t in EXPECTED_KPI_TITLES}
    assert expected_upper.issubset(titles), f"Missing KPI cards: {expected_upper - titles}"

    for title in EXPECTED_KPI_TITLES:
        raw = dash.kpi_value(title)
        normalized = re.sub(r"[₹,\s]", "", raw)
        assert re.match(r"^-?\d+(\.\d+)?$", normalized), (
            f"KPI '{title}' value {raw!r} is not a parseable number"
        )


@pytest.mark.p1
@pytest.mark.smoke
def test_dashboard_quick_access_cards_present(logged_in_page):
    dash = DashboardPage(logged_in_page)
    dash.goto()
    names = set(dash.quick_access_names())
    assert EXPECTED_QUICK_ACCESS.issubset(names), f"Missing Quick Access cards: {EXPECTED_QUICK_ACCESS - names}"


@pytest.mark.p1
@pytest.mark.smoke
def test_dashboard_top_nav_links_present(logged_in_page):
    dash = DashboardPage(logged_in_page)
    dash.goto()
    for link in ["Dashboard", "Patients", "Doctors"]:
        assert dash.top_nav_link_visible(link), f"Top nav link '{link}' not visible"


@pytest.mark.p1
@pytest.mark.regression
def test_total_patients_kpi_matches_actual_patient_count(logged_in_page, api_client):
    """
    Integration check: the 'Total Patients' KPI must equal the real number
    of healthplix.patient records, verified independently via the API
    rather than trusting the UI to have counted its own data correctly.
    """
    dash = DashboardPage(logged_in_page)
    dash.goto()
    kpi_value = int(dash.kpi_value("Total Patients"))

    count_result = api_client.call_kw("healthplix.patient", "search_count", [[]])
    actual_count = count_result["result"]

    assert kpi_value == actual_count, (
        f"Dashboard shows {kpi_value} total patients but {actual_count} patient records actually exist"
    )
