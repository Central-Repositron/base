"""
Flagship P0 regression test — covers TC-APT-05 / TC-BILL-02 from
02_Test_Cases_and_Data.md, reproducing BUG-01 end-to-end:

    Appointment (negative fee) -> Confirm -> Create Billing -> Billing total

This is the highest-risk defect found during this engagement: a negative
consultation fee is accepted on the Appointment form, survives the
Draft -> Confirmed transition, and flows straight through into a real
Billing record's Total Amount with no validation at any stage. (Manual
verification during this engagement additionally followed the chain one
step further into a real Odoo Accounting draft Customer Invoice with a
negative total — that step is intentionally NOT automated here to avoid
creating spurious draft invoices in Accounting on every CI run.)

This test is expected to FAIL (xfail) until BUG-01 is fixed. If it starts
passing unexpectedly (XPASS) with `strict=True`, the run will fail loudly —
that's the signal to remove the xfail marker and close the regression.
"""
import os
import pytest
import config
from pages.doctor_page import DoctorPage
from pages.patient_page import PatientPage
from pages.appointment_page import AppointmentPage
from pages.billing_page import BillingPage
from utils import unique_suffix, future_date_str


@pytest.mark.p0
@pytest.mark.regression
@pytest.mark.xfail(
    reason="BUG-01 (Critical): negative Consultation Fee flows through to a negative Billing total / Invoice",
    strict=True,
)
def test_negative_consultation_fee_should_not_reach_billing(logged_in_page):
    suffix = unique_suffix()

    doc = DoctorPage(logged_in_page)
    doc.goto_list()
    doctor_name = f"QA - Dr. NegFee {suffix}"
    doc.create(name=doctor_name)

    pat = PatientPage(logged_in_page)
    pat.goto_list()
    patient_name = f"QA - Patient NegFee {suffix}"
    pat.create(name=patient_name, phone="9123456780")

    appt = AppointmentPage(logged_in_page)
    appt.goto_list()
    appt.create(
        doctor=doctor_name,
        patient=patient_name,
        date=future_date_str(3),
        time="09:00",
        fee="-750.00",
    )
    appt.confirm()
    assert appt.status() == "Confirmed", "Sanity check: appointment should confirm mechanically regardless of fee"

    appt.create_billing()
    bill = BillingPage(logged_in_page)
    total = float(bill.total_amount())

    logged_in_page.screenshot(path=os.path.join(config.EVIDENCE_DIR, "BUG-01_negative_billing_total.png"))

    assert total >= 0, (
        f"Expected a negative appointment fee to be blocked before reaching Billing, "
        f"but Billing '{bill.bill_no()}' was created with Total Amount = {total}"
    )
