"""Covers TC-AUTH-01 / TC-AUTH-02 from 02_Test_Cases_and_Data.md"""
import pytest
import config
from pages.login_page import LoginPage


@pytest.mark.p0
@pytest.mark.smoke
def test_login_with_valid_credentials(page):
    login = LoginPage(page)
    login.goto()
    login.login()
    page.wait_for_url("**/odoo/**", timeout=config.DEFAULT_TIMEOUT_MS)
    assert "/odoo/" in page.url, "Expected redirect into the Odoo backend after login"


@pytest.mark.p0
def test_login_with_invalid_password_is_rejected(page):
    login = LoginPage(page)
    login.goto()
    login.login(username=config.USERNAME, password="wrong-password-123")
    page.wait_for_timeout(1000)
    assert "/web/login" in page.url, "Should remain on the login page after a bad password"
    assert login.error_message() is not None, "Expected an error message to be shown"
