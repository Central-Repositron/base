import time
import datetime


def unique_suffix() -> str:
    """A short, sortable suffix so repeated test runs don't collide on a
    shared, non-resettable QA database. All test-created records should be
    prefixed 'QA -' (see Test Strategy s4.3) so they're easy to identify
    and clean up."""
    return time.strftime("%Y%m%d-%H%M%S")


def future_date_str(days: int = 5) -> str:
    """A future date formatted MM/DD/YYYY, matching the backend Odoo
    Appointment form's display/input format observed during exploration."""
    d = datetime.date.today() + datetime.timedelta(days=days)
    return d.strftime("%m/%d/%Y")


def unique_past_date_iso() -> str:
    """
    A past date that's different on every call (seeded off the current
    time), formatted YYYY-MM-DD for the public booking form's native date
    input. Using a *fixed* past date across repeated test runs risks a
    false pass: the app enforces one-slot-per-doctor-per-time, so a second
    run reusing the same doctor+date+time collides on "slot unavailable"
    rather than genuinely re-testing past-date validation.
    """
    days_ago = 2000 + (int(time.time()) % 1000)
    return (datetime.date.today() - datetime.timedelta(days=days_ago)).isoformat()


def unique_time_str() -> str:
    """A time in HH:MM that varies per call, to avoid slot collisions."""
    minute = int(time.time()) % 60
    return f"03:{minute:02d}"
