# Test Strategy — Shivansh Cancer Center (Odoo Hospital Management)

**Application Under Test (AUT):** https://team63.qaaglobal.com
**Entry point tested:** `/odoo/action-372` (Hospital Operations Dashboard) + public site (`/`, `/doctor/list`, `/health_plix/book`)
**Prepared:** 2026-07-11
**Test account used:** `team63` (internal/backend user)

---

## 1. Application Overview

The AUT is a custom Odoo application implementing a Hospital / OPD & IPD Management System for "Shivansh Cancer Center". It has two faces:

1. **Backend (internal, authenticated) app** — reached via `/odoo/...` actions, used by hospital staff (reception, doctors, billing desk). Modules discovered on the Dashboard and **Management** menu:
   - Patients, Doctors
   - Appointments, IPD Registrations, IPD Management
   - Prescriptions, Lab Reports, Lab Test Types
   - Treatment Sheets, History & Physical, Progress Sheets, Pre-Op Checklist
   - Ward Management, Bed Management, Fluid Balance Charts, Vital Sign Charts
   - Billing (integrates with Odoo Accounting `account.move` invoices)
2. **Public website (anonymous)** — marketing site with:
   - `/doctor/list` — doctor directory
   - `/health_plix/book` — 3-step public appointment booking form (Specialist → Patient Info → Date & Time), which writes directly into the same backend Patient/Appointment models.

Because the public booking form and the backend Appointment form both feed the **same** Patient → Appointment → Billing → Invoice pipeline, this pipeline is the highest-value, highest-risk area of the application and is weighted accordingly throughout this strategy.

## 2. Objectives

- Verify that core hospital workflows (registration → appointment → consultation → prescription/lab → billing → invoice → payment) are functionally correct end-to-end.
- Verify data integrity and validation at every entry point that can create or mutate a Patient, Appointment, or Billing record — including the **unauthenticated public booking form**, since it is a direct, unauthenticated write path into clinical/financial data.
- Establish a regression-safe automated suite for the highest-risk flows so future changes can be verified quickly.
- Surface defects and UX/enhancement opportunities to the product owner in a form that is triageable and reproducible.

## 3. Scope

### 3.1 In Scope
| Area | Notes |
|---|---|
| Authentication | Login, logout, reset password link, session handling |
| Patients | Create/read/update, UHID generation, linked Customer partner, document upload |
| Doctors | Create/read/update, specialization, experience, contact validation |
| Appointments (backend) | Draft → Confirmed → Done lifecycle, Cancel, Create Billing, Print Receipt |
| Public Booking (`/health_plix/book`) | 3-step form, doctor selection, date/time selection, confirmation page, resulting backend records |
| Prescriptions | Patient/Appointment linkage, medicine lines, print |
| Lab Reports | Creation, status, linkage to patient/doctor |
| Billing & Invoicing | Bill creation from appointment, billing lines, Create Invoice → Odoo Accounting, payment status lifecycle |
| IPD Registration (smoke only) | Registration form fields and list view |
| Ward/Bed Management (smoke only) | List views, master data |
| Cross-cutting | Required-field validation, numeric/date/email/phone format validation, negative-value handling, list view aggregates, autosave behavior |

### 3.2 Out of Scope (this pass)
- Deep IPD clinical documentation modules (Treatment Sheets, History & Physical, Progress Sheets, Pre-Op Checklist, Fluid Balance/Vital Sign Charts) — recommend a follow-up pass once core OPD flow is stabilized.
- Odoo Accounting configuration (chart of accounts, tax setup) beyond invoice creation.
- Performance/load testing, penetration testing.
- Multi-user/role-based permission testing (only one internal role — `team63` — was available for this engagement).
- Email/SMS notification delivery (confirmation copy says "we'll email you" — not verified in this pass; flagged as a gap, see Enhancements).

## 4. Test Approach

### 4.1 Levels
- **Smoke testing** — Login + each module opens without error, dashboard counters update.
- **Functional testing** — CRUD and workflow-state transitions per module (see Test Cases doc).
- **Boundary / negative testing** — required fields, min/max numeric bounds, invalid formats, past/future dates, empty vs. overlong strings. This app's field-level validation is visibly thin (see Bugs report), so this is the primary defect-finding technique used.
- **Integration testing** — cross-module propagation, specifically Appointment fee → Billing line → Invoice amount, and Public Booking → backend Patient/Appointment creation.
- **Regression testing (automated)** — the flows above are candidates for the Playwright automation suite (see `03_Automation_Framework/`), to be run on every deploy.
- **Exploratory testing** — time-boxed charter-based sessions on modules not covered by scripted cases, targeting the "same shape of bug" (missing validation) in less-obvious fields.

### 4.2 Techniques
- Equivalence partitioning + boundary value analysis on numeric/date fields (fee, experience, quantity, dates, times).
- State-transition testing on workflow status bars (Appointment: Draft/Confirmed/Done; Billing: Draft/Invoiced/Partially Paid/Paid; Invoice: Draft/Posted).
- Decision-table testing for the public booking form's 3-step validation (which fields are required at which step, client-side vs. server-side).
- Data-driven testing for the automation suite (parametrized valid/invalid data sets — see Test Data section of the Test Cases doc).

### 4.3 Test Environment
- **URL:** https://team63.qaaglobal.com (shared QA/UAT instance — treat as a shared environment, not a sandbox: avoid destructive bulk actions, clearly label test data e.g. `"QA - "` prefix, clean up where possible).
- **Browsers:** Chromium (primary, via Playwright). Cross-browser pass (Firefox/WebKit) recommended before major releases given the app is a standard Odoo web client.
- **Test data:** Synthetic only — no real patient (PII/PHI) data is to be used, per standard healthcare-app testing practice, even though this is a demo instance.
- **Accounts:** Single internal user `team63` was available. Recommend requesting a second, lower-privileged user (e.g. "receptionist" vs "doctor" vs "billing") before role/permission testing.

### 4.4 Entry / Exit Criteria
**Entry:** Build deployed to the QA URL and reachable; login works; dashboard loads.
**Exit (per cycle):**
- 100% of P0/P1 test cases executed.
- No open Critical/High severity defects in the Appointment→Billing→Invoice chain (this is the app's financial integrity boundary).
- All defects logged with repro steps, evidence, and severity (see `04_Bugs_and_Enhancements.md`).
- Automated regression suite green on the build.

## 5. Risk-Based Prioritization

| Risk | Likelihood (observed) | Impact | Priority |
|---|---|---|---|
| Negative/invalid monetary values reach real invoices | **Confirmed** | Financial/audit integrity | **P0** |
| Public, unauthenticated form writes clinical data with no date/time/format validation | **Confirmed** | Data integrity, scheduling chaos, potential abuse (spam bookings) | **P0** |
| Missing format validation on contact fields (phone/email) | **Confirmed** | Downstream comms failure (no valid contact to reach patient) | **P1** |
| Inconsistent/misleading validation error messaging | **Confirmed** | User confusion, support burden | **P2** |
| Sequence/numbering gaps on Patient UHID | Observed once | Audit trail cleanliness in a regulated (healthcare) context | **P2** |
| Deep IPD clinical modules unvalidated | Not tested this pass | Clinical safety if used in production | **P1** (flag for next cycle) |

## 6. Tools

| Purpose | Tool |
|---|---|
| Automation framework | Playwright (Python) + pytest, Page Object Model |
| Test/bug tracking | This repo's Markdown docs (`02_`, `04_`) — recommend promoting to Jira/Linear for team use |
| CI | GitHub Actions (suggested `automation/.github/workflows/tests.yml` — not wired to a real repo in this exercise) |
| Reporting | `pytest-html` for local HTML reports; screenshots/traces on failure via Playwright trace viewer |

## 7. Roles & Responsibilities (suggested for a real engagement)
- **QA Engineer:** test design, execution, automation, defect logging.
- **Dev/Product Owner:** defect triage, prioritization, fixes.
- **Release Manager:** exit-criteria sign-off before promoting build.

## 8. Deliverables (this engagement)
1. `01_Test_Strategy.md` — this document.
2. `02_Test_Cases_and_Data.md` — detailed functional + negative test cases with sample test data.
3. `03_Automation_Framework/` — runnable Playwright/Python POM framework covering the P0/P1 flows, including a regression test that reproduces the negative-fee defect.
4. `04_Bugs_and_Enhancements.md` — defects found during this pass (all reproduced live on the QA instance) and enhancement recommendations.
