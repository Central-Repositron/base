# Bugs & Enhancements — Shivansh Cancer Center (Odoo Hospital App)

**Environment:** https://team63.qaaglobal.com (QA/UAT), user `team63`
**Found during:** manual exploratory testing + automated UI regression suite + direct JSON-RPC API probing, 2026-07-11
**All defects below were reproduced live** on the QA instance (several are also encoded as automated regression tests in `03_Automation_Framework/tests/`, marked `xfail` until fixed — see that folder's README for what that means). BUG-01, BUG-02, and BUG-13 were additionally confirmed via raw `POST /web/dataset/call_kw` requests that bypass the browser UI entirely, proving these are server-side model gaps rather than missing client-side checks.

Severity scale: **Critical** (data/financial integrity, no workaround) · **High** (major functional gap, workaround exists) · **Medium** (validation gap, limited blast radius) · **Low** (UX/cosmetic).

---

## BUG-01 — Negative Consultation Fee flows through to a real negative Invoice
**Severity:** Critical | **Module:** Appointments → Billing → Accounting | **Automated:** `test_billing_negative_fee.py`

**Steps to reproduce:**
1. Management → Appointments → New.
2. Select any Doctor and Patient, a valid future Date/Time.
3. Set **Consultation Fee = `-500.00`**.
4. Click **Confirm**.
5. Click **Create Billing**.
6. On the resulting Bill, click **Create Invoice**.

**Expected:** The negative value should be rejected the moment it's entered on the Appointment (or, at latest, blocked before the Confirm/Create Billing/Create Invoice actions).

**Actual:** No validation at *any* of the four stages:
- Appointment saves and **Confirms** with Fee `-500.00`.
- Billing record `BILL/00001` is created with **Total Amount `-500.00`**, Status `Invoiced`.
- The Billing list view's aggregate **footer total** also shows `-500.00` (mathematically correct — it's just summing bad data).
- A real Odoo Accounting **draft Customer Invoice** (`INV/2026/00001`) is generated with **Total `$-500.00`**, **Amount Due `$-500.00`**, linked to the patient as Customer.

**Evidence:** Reproduced end-to-end during this engagement; invoice deliberately left in **Draft** (not posted) to avoid creating a real negative ledger entry on the shared instance.

**Confirmed server-side, not just UI:** A raw JSON-RPC `call_kw` against `healthplix.appointment.create()` with `cost: -12345` (bypassing the browser UI entirely — no JS validation could ever have run) succeeded and returned a new record id, and a follow-up `read()` confirmed the negative value persisted verbatim (`appointment_date: "2019-05-05", cost: -12345`, `state: "draft"`). This proves the gap is in the model layer (no `@api.constrains`), not merely a missing client-side check — **any** API consumer (a future mobile app, an integration, or a valid session token used outside the browser) can write the same bad data, so a JS-only fix would not close this.

**Impact:** This is a live path from a single mistyped/malicious number in an Appointment form to a real negative invoice in the accounting system — a direct financial-integrity and audit-trail risk. In a production hospital deployment this could mean the hospital owes the patient money for a consultation, silently, with no approval gate. Because the gap is server-side, it's also reachable by anything that can call the API, not just the form.

**Recommendation:** Add a `CHECK (cost >= 0)` style constraint (or Odoo `@api.constrains`) on `healthplix.appointment.cost`, `healthplix.billing.total_amount`/line unit prices, and mirror the same floor on the standard invoice line creation. Validate both client-side (immediate feedback) and server-side (authoritative — the client-side check alone would not have caught this, since the public site and backend are two different UIs hitting the same model).

---

## BUG-02 — Appointment date/time accepts past dates and out-of-hours times, in both the backend and the public booking form
**Severity:** High | **Module:** Appointments (backend) + Public Booking (`/health_plix/book`) | **Automated:** `test_appointment.py::test_appointment_date_rejects_past_date`, `test_public_booking.py::test_public_booking_rejects_past_date`, `test_public_booking.py::test_public_booking_rejects_out_of_hours_time`

**Steps to reproduce (backend):**
1. Management → Appointments → New.
2. Set Date = `01/01/2024` (a past date). Save.

**Steps to reproduce (public site — more severe, unauthenticated):**
1. Open `/health_plix/book` in an incognito window (no login).
2. Fill the form; set Appointment Date = `01/01/2020` and Preferred Time = `03:00`.
   (The page itself states: *"OPD Hours: Mon–Sat 9:00am – 6:00pm | Sun 10:00am – 2:00pm | Emergency: 24×7"* directly above the fields.)
3. Click **Confirm Appointment**.

**Expected:** Both entry points should reject a date in the past. The public form should additionally reject a time outside the stated OPD hours (or route it into a distinct "Emergency" flow with different messaging/handling).

**Actual:** Both accepted silently.
- Backend: appointment `APT/0001` saved and was later **Confirmed** with the past date, no warning.
- Public site: booking `APT/0002` for 01/01/2020 at 3:00 AM was accepted, and the page displayed **"Appointment Confirmed!"** with a confirmation reference. It created a real Patient (`PAT/00003`) and Appointment in the backend — visible in the Dashboard's "Total Patients"/"OPD Appointments" counters incrementing.

**Impact:** Since this form requires no authentication, this is a public, unauthenticated write path into clinical scheduling data with no temporal sanity checking at all — trivially exploitable for spam bookings, scheduling chaos, or (combined with BUG-01-style gaps elsewhere) data-quality corruption. Front-desk staff have no way to distinguish a "real" past-dated legacy-migration appointment from one submitted in error or maliciously.

**Confirmed server-side, not just UI:** the same direct `call_kw` API request from BUG-01 (`appointment_date: "2019-05-05"`) was accepted with no date-related error — only a *different* rule (`_check_double_booking`, doctor/slot conflict) can ever reject a `create()` call server-side. There is no `_check_valid_date`-style constraint at all in the model.

**Recommendation:**
- Client-side: set the HTML5 date input's `min` attribute to today's date on the public form (a one-line fix) and validate the time against the OPD hours before enabling submit.
- Server-side (authoritative, covers the backend form too): reject `appointment_date < today` and, for public submissions specifically, reject times outside the configured OPD window unless an explicit "Emergency" flag is set.

---

## BUG-12 — Public booking confirmation says "Confirmed" but the backend record is left in Draft status
**Severity:** High | **Module:** Public Booking → Appointments

**Steps to reproduce:**
1. Complete a booking on `/health_plix/book` (any valid data).
2. Note the confirmation page: **"Appointment Confirmed!"** with `Confirmation: APT/000x`.
3. Log into the backend and open that same Appointment.

**Expected:** If the public-facing copy asserts the appointment is confirmed, the backend `state` field should be `Confirmed`.

**Actual:** The backend record is left in **Draft** (with `Fee = 0.00`, unset by design since the public form doesn't collect a fee). Verified directly via the Appointments list view.

**Impact:** Two audiences get two different, contradictory truths from the same record: the patient believes their slot is locked in; front-desk staff see it as an un-actioned Draft alongside every other unconfirmed request. If staff don't proactively review the Appointments list, a patient who was told "Confirmed" may show up to an appointment that was never actually scheduled/staffed.

**Recommendation:** Either (a) rename the public-facing copy to "Request Received" / "Booking Submitted — pending confirmation" to match the actual Draft state, or (b) if walk-in-style auto-confirmation is the intended business rule, have the public booking controller explicitly transition the created record to `Confirmed` (and only then show "Confirmed" copy). Pick one and make the two consistent.

---

## BUG-03 — Doctor "Experience (Years)" accepts negative values
**Severity:** Medium | **Module:** Doctors | **Automated:** `test_doctor.py::test_doctor_experience_rejects_negative_value`

**Steps to reproduce:** Doctors → New → set Experience (Years) = `-5` → Save.
**Expected:** Rejected or floored at 0.
**Actual:** Saves and displays `-5` in both the form and the list view.
**Recommendation:** Add a non-negative constraint on the `experience` field (simple `min="0"` on the widget plus a server-side `@api.constrains`).

---

## BUG-04 — Phone field accepts non-numeric text
**Severity:** Medium | **Module:** Doctors (also observed as a general pattern — see Enhancement E-4) | **Automated:** `test_doctor.py::test_doctor_phone_rejects_non_numeric`

**Steps to reproduce:** Doctors → New → set Phone = `abcd123` → Save.
**Expected:** Rejected, or restricted to digits/formatting characters by input mask.
**Actual:** Saves literal text `abcd123` as the phone number; visible as-is in the Doctors list.
**Impact:** A hospital cannot call a patient/doctor back using a corrupted contact field — directly undermines the "Emergency Helpline" / callback promise made on the public site.
**Recommendation:** Numeric input mask + server-side regex validation (e.g., `^\+?[0-9\s-]{7,15}$`).

---

## BUG-05 — Email field accepts syntactically invalid text
**Severity:** Medium | **Module:** Doctors | **Automated:** `test_doctor.py::test_doctor_email_rejects_invalid_format`

**Steps to reproduce:** Doctors → New → set Email = `not-an-email` → Save.
**Expected:** Rejected with an inline format error.
**Actual:** Saves as literal text with no `@`/domain, no error shown.
**Note (positive finding, for balance):** A *related* control does work correctly — the Doctor Email field is tied to a linked portal-user login, and Odoo's own uniqueness constraint ("You can not have two users with the same login!") correctly blocks two doctors from sharing the same email, surfaced via a clear blocking "Validation Error" dialog. So uniqueness is enforced; *format* is not.
**Recommendation:** Add standard email-format validation (Odoo has a built-in email widget/constraint pattern used elsewhere in the suite — apply it here) in addition to the existing uniqueness check.

---

## BUG-06 — Public booking "Mobile Number" field has no maximum length
**Severity:** Low–Medium | **Module:** Public Booking | **Automated:** `test_public_booking.py::test_public_booking_mobile_number_has_length_limit`

**Steps to reproduce:** On `/health_plix/book`, enter a 20-digit string (`99999999999999999999`) into Mobile Number → submit.
**Expected:** Field enforces a realistic max length (10–15 digits) client-side, or is rejected server-side.
**Actual:** Accepted in full with no truncation or error (found incidentally while testing another field — the input has no `maxlength` attribute and no pattern validation).
**Recommendation:** Add `maxlength` + a digit-count pattern (`\d{10,15}`) matching the placeholder's implied format (`+91 XXXXX XXXXX`).

---

## BUG-08 — Appointment Time field silently discards invalid input with no error message
**Severity:** Low | **Module:** Appointments (backend)

**Steps to reproduce:** New Appointment → set Time (HH:MM) = `99:99` → move focus to another field.
**Expected:** A validation error is shown, or the input is constrained as you type.
**Actual:** The field silently reverts to `00:00` with **no message at all** — the user has no way to know their input was rejected versus simply not yet saved.
**Impact:** Low severity but a real trust/usability problem: a receptionist typing a time quickly could end up with every appointment defaulting to midnight without noticing.
**Recommendation:** Either constrain input as-you-type (mask to `00`–`23` / `00`–`59`) or show a toast/inline error identical in spirit to the "Missing required fields" pattern already used elsewhere in the app.

---

## BUG-09 — Inconsistent "Missing required fields" messaging on the Patient form
**Severity:** Low | **Module:** Patients (observed pattern likely present elsewhere)

**Steps to reproduce:** Patients → New → type only a Name → click away (autosave triggers).
**Expected:** Either the record is genuinely blocked from saving until all required fields are filled, with the toast naming the specific field(s); or, if Name truly is the only required field, no "Missing required fields" toast should appear at all.
**Actual:** A "Missing required fields" toast appears transiently, but the record **saves anyway** (as `PAT/00002`) with every other field empty. The toast never names which field it means.
**Recommendation:** (1) Make the toast identify the specific field(s) by label, not a generic message. (2) Audit whether the toast is even accurate here — if Name-only is a valid save, the toast is simply wrong and should be suppressed.

---

## BUG-10 — Patient UHID sequence has a gap on first use
**Severity:** Low (data-hygiene / audit-trail concern in a healthcare context) | **Module:** Patients

**Observation:** In a session where no Patient records existed yet, opening a blank "New" Patient form and then creating the very first real record resulted in UHID **`PAT/00002`**, not `PAT/00001` — i.e., the sequence number appears to advance (or be reserved) even when a "New" form is opened and not saved, rather than only incrementing on an actual committed save.
**Impact:** In most business software this is a shrug; in a hospital's patient identifier scheme, gaps in a supposedly sequential UHID can raise audit questions ("where did PAT/00001 go?") during compliance review.
**Recommendation:** Verify whether the sequence is drawn via `ir.sequence.next_by_code` in a `default_get`/`onchange` (draw-on-open) versus only on `create()` (draw-on-save). If the former, switch to draw-on-save so abandoned drafts don't burn UHID numbers.

---

## BUG-11 — Some list views render fully blank for ~1 second with no loading indicator
**Severity:** Low (UX polish) | **Module:** Doctors, IPD Registrations (observed; likely others)

**Steps to reproduce:** Navigate to Management → Doctors (or IPD Registrations) from a cold click.
**Expected:** A spinner/skeleton while data loads, so the view never looks "broken."
**Actual:** A completely blank white page is shown for roughly a second before the list/columns render.
**Recommendation:** Confirm Odoo's default loading skeleton is enabled for these custom views (this is usually automatic — worth checking if a custom template/widget is suppressing it).

---

## BUG-13 — Verbose Python stack traces leaked in every JSON-RPC error response, including to unauthenticated callers
**Severity:** Medium (information disclosure) | **Module:** Platform-wide (`/web/dataset/call_kw`) | **Automated:** `test_api_direct_validation.py`

**Steps to reproduce:**
1. Send any request to `POST /web/dataset/call_kw` that triggers a server-side exception — e.g. an authenticated `create()` call that hits the double-booking constraint, or simply an **unauthenticated** call to any model method.
2. Inspect the JSON response body.

**Actual:** The `error.data.debug` field contains a full Python traceback with **absolute internal file paths** (`/opt/odoo/odoo/http.py`, `/opt/odoo/addons/health_plix/models/appointment.py`, exact line numbers, the ORM call chain, decorator internals). This was observed both on an authenticated validation-error response and on a plain `SessionExpiredException` sent with no session cookie at all — i.e., **no authentication is required to receive a full server traceback.**

**Expected:** Error responses should return a clean, user-safe message (e.g. `{"message": "This time slot is not available"}`) without internal file-system paths, module structure, or stack internals — especially to unauthenticated requests.

**Impact:** This isn't directly exploitable on its own, but it's meaningful reconnaissance for an attacker: it confirms the exact addon name (`health_plix`), server install path (`/opt/odoo/...`), and internal method/constraint names, which narrows the search for further vulnerabilities and version-specific exploits. Standard hardening guidance (OWASP, Odoo's own production docs) is to disable `debug` traceback exposure in production.

**Recommendation:** Confirm the instance's `dev`/`debug` mode is genuinely disabled for anything resembling production, and check whether `error.data.debug` is stripped for non-admin/unauthenticated sessions regardless of debug mode.

---

## Positive Findings (for balance — not everything is broken)

Verified via the same direct-API probing used to confirm BUG-01/02/13:

- **Session authentication is correctly enforced.** An unauthenticated `call_kw` request (cookie explicitly omitted) was rejected with `SessionExpiredException` rather than executing — the API surface itself is not open to anonymous read/write.
- **Doctor/slot double-booking IS validated server-side.** `healthplix.appointment` has a real `_check_double_booking` constraint that correctly blocked a second appointment for the same doctor at an already-booked date/time, both via the UI and via direct API — this is a genuinely working business-rule guard, just narrower in scope than it should be (it checks slot conflicts but not date validity or fee sign).
- **Doctor email uniqueness (linked portal-user login) is enforced** (see BUG-05's note) with a clear blocking dialog, not a silent failure.

---

## Summary Table

| ID | Title | Severity | Status |
|---|---|---|---|
| BUG-01 | Negative fee reaches real invoices | **Critical** | Open |
| BUG-02 | Past date / out-of-hours bookings accepted (backend + public) | **High** | Open |
| BUG-12 | Public "Confirmed" copy vs. backend Draft status mismatch | **High** | Open |
| BUG-03 | Doctor Experience accepts negative values | Medium | Open |
| BUG-04 | Phone field accepts non-numeric text | Medium | Open |
| BUG-05 | Email field accepts invalid format | Medium | Open |
| BUG-06 | Public Mobile Number has no length limit | Low–Medium | Open |
| BUG-08 | Time field silently discards invalid input | Low | Open |
| BUG-09 | Misleading "Missing required fields" toast on Patient form | Low | Open |
| BUG-10 | Patient UHID sequence gap | Low | Open |
| BUG-11 | Blank list-view flash, no loading indicator | Low | Open |
| BUG-13 | Verbose server tracebacks leaked in API errors (incl. unauthenticated) | Medium | Open |

---

## Enhancement Recommendations

These are not defects against a documented spec, but improvements worth prioritizing alongside the fixes above:

**E-1. Centralize contact-field validation.** BUG-04/05/06 are all instances of the same underlying gap — phone/email fields across Doctor, Patient, and the public booking form don't share a common validation layer. Recommend a single reusable validator (Odoo mixin or JS widget) applied everywhere a phone/email is collected, rather than fixing each field independently.

**E-2. Duplicate-patient detection.** Neither the backend Patient form nor the public booking form appears to check for an existing patient by phone/email before creating a new one (not confirmed as a defect in this pass — flagged as TC-PAT-07/TC-PUB-07, **Not Run** — but worth prioritizing given the pattern of missing validation found elsewhere). A repeat patient booking through the public site risks fragmenting one person's medical history across multiple `PAT/xxxxx` records.

**E-3. Confirmation-step guardrails on irreversible actions.** Confirm / Mark as Done / Create Invoice all fire immediately on click with no "are you sure?" step and no re-validation of the record's financial fields at the point of transition. Given BUG-01, adding a validation gate *at the transition*, not just at field-entry time, would have caught the negative fee even if the field itself were never fixed (defense in depth).

**E-4. Notification/reminder delivery is unverified.** The public booking page promises *"We'll send a confirmation to your email within 2 hours of booking"* — this was out of scope to verify in this pass (no email inbox access) but should be explicitly tested before go-live, since a confirmed appointment with no actual notification sent is a silent failure mode.

**E-5. Second, lower-privileged test account.** Only one internal user (`team63`) was available for this engagement, so no role/permission testing (e.g., can a receptionist see billing? can billing staff edit clinical notes?) was possible. Recommend provisioning at least a "Reception" and a "Billing" role account before the next test cycle.

**E-6. Deep-test the IPD/clinical modules.** Ward Management, Bed Management, Treatment Sheets, History & Physical, Progress Sheets, Pre-Op Checklist, Fluid Balance Charts, and Vital Sign Charts were only smoke-tested (list views load) in this pass. Given the density of validation gaps found in the simpler OPD flow, these clinical-documentation modules should be a high priority for the next test cycle — errors there have direct patient-safety implications.
