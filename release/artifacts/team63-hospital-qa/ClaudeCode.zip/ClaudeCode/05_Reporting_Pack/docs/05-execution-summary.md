# 05 — Execution Summary

## Run Information
- Project: Shivansh Cancer Center (team63) QA
- Environment: `https://team63.qaaglobal.com`
- Executed by: Claude (agentic session), live against the real QA instance
- Execution date: 2026-07-11
- Framework: Playwright (Python) + pytest, `03_Automation_Framework/`

## Results Snapshot (final, verified run)

| Metric | Value |
|---|---:|
| Total automated test cases executed | 22 |
| Passed | 11 |
| XFAIL (known defect, reproduced as expected) | 11 |
| Unexpected failures / errors | 0 |
| Pass rate (of non-defect cases) | 11/11 = 100% |

Full run: `reports/ui/report.html` + `reports/ui/junit.xml`. API-layer subset only: `reports/api/report.html` + `reports/api/junit.xml` (4 tests: 1 pass, 3 xfail).

## Tests Executed (Automated)

**Passing (11)** — core functionality genuinely works:
- `test_login.py` — valid login, invalid-password rejection (2)
- `test_doctor.py::test_create_doctor_with_valid_data`
- `test_patient.py::test_create_patient_with_valid_data`
- `test_appointment.py::test_create_appointment_with_valid_future_date`
- `test_public_booking.py::test_public_booking_happy_path`
- `test_dashboard.py` — KPI render, quick-access, top-nav, KPI-vs-actual-count (4)
- `test_api_direct_validation.py::test_unauthenticated_call_kw_is_rejected`

**XFAIL — reproduced defects (11)**, each tied to a `defects/defects.csv` row:
- `test_billing_negative_fee.py` → DEF-001 (Critical)
- `test_api_direct_validation.py::test_api_negative_fee_bypasses_model_validation` → DEF-001, confirmed server-side
- `test_appointment.py::test_appointment_date_rejects_past_date` → DEF-002
- `test_api_direct_validation.py::test_api_past_date_bypasses_model_validation` → DEF-002, confirmed server-side
- `test_public_booking.py::test_public_booking_rejects_past_date` → DEF-002
- `test_public_booking.py::test_public_booking_rejects_out_of_hours_time` → DEF-002
- `test_doctor.py::test_doctor_experience_rejects_negative_value` → DEF-004
- `test_doctor.py::test_doctor_phone_rejects_non_numeric` → DEF-005
- `test_doctor.py::test_doctor_email_rejects_invalid_format` → DEF-006
- `test_public_booking.py::test_public_booking_mobile_number_has_length_limit` → DEF-007
- `test_api_direct_validation.py::test_api_error_response_does_not_leak_traceback` → DEF-012

Plus manually-verified defects not yet automated: DEF-003, DEF-008, DEF-009, DEF-010, DEF-011 (see `defects/defects.csv`).

## Defect Summary (This Engagement)

| Severity | Count |
|---|---:|
| Critical | 1 |
| High | 2 |
| Medium | 3 |
| Low | 6 |
| **Total** | **12** |

## Integrity Note: Every XFAIL Was Verified to Fail for the Right Reason

Before finalizing this run, every `xfail` test was force-executed with `pytest --runxfail` (which bypasses the xfail marker and reports the real pass/fail outcome) to confirm it fails on its *intended* assertion — not an unrelated timeout or a different exception that would happen to also count as "failed." This caught and fixed three real automation bugs in the page objects (a read-only field misread as an editable input, a status-transition race condition, a date-widget whose DOM shape changes after save — see `03_Automation_Framework/README.md` "Lessons learned" section for detail). All 11 xfail tests now fail on exactly the assertion documented in their `reason=` string, confirmed via direct traceback inspection.

## Module-wise Status

| Module | Automated Coverage | Manual/Smoke Coverage | Defects |
|---|---|---|---|
| Authentication | 3 tests (2 UI + 1 API) | — | 0 |
| Doctors | 4 tests | Uniqueness check (positive) | 3 |
| Patients | 1 test | UHID gap, toast messaging | 2 |
| Appointments (backend) | 3 tests (incl. 2 API) | Time-field UX, double-booking (positive) | 3 |
| Public Booking | 4 tests | Status-mismatch check | 3 |
| Billing/Invoicing | 1 test (flagship) | Invoice-level chain verification | 1 (shared) |
| Dashboard | 4 tests | — | 0 |
| Platform/API security | 2 tests | — | 1 |
| Prescriptions, Lab Reports, IPD, Ward/Bed | 0 tests | List-view field inventory only | 0 (not deep-tested) |

## Go/No-Go Recommendation

**Status: Red (No-Go for production) on the current build.**

Rationale: one **Critical** defect (DEF-001) allows a negative consultation fee to reach a real Accounting invoice with zero validation at any layer, confirmed both through the UI and through a direct, unauthenticated-bypass-proof API call. Two **High** defects (DEF-002, DEF-003) mean the public-facing booking flow can write invalid clinical scheduling data and misrepresents its own confirmation state. None of these have a workaround available to end users — they require a code fix, not a process change.

**Before this build could be considered for release:** DEF-001, DEF-002, and DEF-003 must be fixed and their corresponding `xfail` markers removed (each will XPASS and fail the run loudly if fixed, which is the verification signal). DEF-004 through DEF-012 should be triaged and scheduled but do not block a release on their own.

## Attachments
- UI report: `reports/ui/report.html`, `reports/ui/junit.xml`
- API report: `reports/api/report.html`, `reports/api/junit.xml`
- Evidence: `evidence/screenshots/` (2 real screenshots), `evidence/api/` (3 real raw JSON-RPC request/response captures)
- Defect log: `defects/defects.csv` (12 rows, all reproduced), `defects/enhancements.csv` (7 rows)
