# Prompt Log

Tracks the meaningful instructions used to produce this QA pack, for transparency.

| Timestamp (IST) | Prompt/Instruction | Purpose | Output Artifact |
|---|---|---|---|
| 2026-07-11 | "Test Strategy, Test Cases/Data, Automation Framework + Scripts, Bugs/Enhancements" for the QA test site, with login credentials supplied | Initial end-to-end QA engagement | `01_Test_Strategy.md`, `02_Test_Cases_and_Data.md`, `03_Automation_Framework/`, `04_Bugs_and_Enhancements.md` |
| 2026-07-11 | Live exploration of every backend module (Patients, Doctors, Appointments, Prescriptions, Lab Reports, IPD, Billing, Ward/Bed Management) plus the public booking website, deliberately probing boundary/negative values | Ground the strategy and test cases in real, observed field-level behavior rather than inferred menu labels | `docs/01-system-inventory.md` |
| 2026-07-11 | Built and ran a real Playwright (Python) + pytest framework against the live site — installed dependencies, wrote Page Objects, iterated until every test genuinely passed/xfailed for the right reason | Verified, not speculative, automation | `03_Automation_Framework/` (final clean run: see `05-execution-summary.md`) |
| 2026-07-11 | Given a competing PostQode-generated QA pack for the same target and asked to: (1) identify coverage gaps, (2) build a comparable presentation-ready reporting pack, (3) produce a focused high-value test suite, (4) cherry-pick good ideas from a ChatGPT-authored PostQode playbook | Comparative gap analysis + this reporting pack | `05_Reporting_Pack/` (this pack), `06_Comparison_Notes.md` |
| 2026-07-11 | Verified two of the found UI defects (negative fee, past-date booking) by hitting Odoo's JSON-RPC `/web/dataset/call_kw` directly, bypassing the browser entirely, to determine whether the gap was client-side or server-side | Proves severity/root cause precisely rather than assuming | `03_Automation_Framework/api_client.py`, `03_Automation_Framework/tests/test_api_direct_validation.py`, `defects/defects.csv` DEF-001/DEF-002/DEF-012 |
| 2026-07-11 | Added Dashboard KPI-vs-actual-data integration test (adopted from reviewing the competing pack's use of `.hp-stat-card` selectors, extended into a genuine data-integrity check rather than a visibility-only check) | Close a real coverage gap found during the comparison | `03_Automation_Framework/tests/test_dashboard.py` |

## Notes
- Every claim of "PASS" or "FAIL" in this pack's CSVs is backed by either an automated test run (`reports/ui/`) or an explicitly-labeled manual verification during live exploration — nothing here is a template placeholder or an unexecuted assumption.
- Update this log for each further QA session against the same target.
