# 03 — Test Strategy (Summary)

Full version: [`../../01_Test_Strategy.md`](../../01_Test_Strategy.md). This is the condensed, presentation-ready version.

## 1. Objective
Validate functional correctness and data integrity of the Shivansh Cancer Center hospital app (Odoo-based, custom `health_plix` module) across its OPD flow — Patient → Doctor → Appointment → Prescription/Lab → Billing → Invoice — plus the public, unauthenticated booking website, since both write into the same backend data.

## 2. Scope
**In scope:** Authentication, Patients, Doctors, Appointments (backend + public booking), Billing/Invoicing, Dashboard KPI integrity, direct API-layer (JSON-RPC) validation. **Smoke only:** Prescriptions, Lab Reports, IPD Registration, Ward/Bed Management. **Out of scope this cycle:** deep clinical-documentation modules, role/permission testing (only one account available), load/performance testing, notification delivery.

## 3. Risk-Based Prioritization
| Priority | Risk | Status |
|---|---|---|
| P0 | Negative/invalid monetary values reaching real invoices | **Confirmed — DEF-001, Critical** |
| P0 | Unauthenticated public form writing clinical data with no date/time validation | **Confirmed — DEF-002, High** |
| P0 | API-layer bypass of UI validation rules | **Confirmed — DEF-001/002 reproduced via raw API** |
| P1 | Missing phone/email format validation | **Confirmed — DEF-005/006** |
| P1 | Server error responses leaking internal detail | **Confirmed — DEF-012** |
| P1 | Dashboard KPI drift from real data | **Checked — currently in sync (no defect)** |
| P2 | Inconsistent/misleading UI messaging | **Confirmed — DEF-003, DEF-009** |

## 4. Test Levels & Technique
- **Smoke**: login, module navigation, dashboard render (`test_login.py`, `test_dashboard.py`)
- **Functional / CRUD**: Doctor, Patient, Appointment creation (`test_doctor.py`, `test_patient.py`, `test_appointment.py`)
- **Boundary / Negative**: primary defect-finding technique — required fields, numeric sign, date range, string format/length across every entry point (all `test_*` files' xfail cases)
- **Integration**: Appointment fee → Billing total → Invoice total propagation (`test_billing_negative_fee.py`); Dashboard KPI vs. real record count (`test_dashboard.py`)
- **API-layer**: direct JSON-RPC `call_kw` probing to determine whether a UI-observed gap is client-side or server-side, and to test unauthenticated access (`test_api_direct_validation.py`)

## 5. Automation Approach
Playwright (Python) + pytest, Page Object Model, for both UI and API layers (one framework, two layers — see `03_Automation_Framework/README.md`). Known-defect regressions are `xfail(strict=True)`: they fail today (documenting the open bug with a live, runnable repro) and will loudly break the run (XPASS) the moment the underlying bug is fixed, which is the signal to remove the marker and close it out.

## 6. Entry / Exit Criteria
**Entry:** QA URL reachable, credentials valid, dashboard loads. **Exit:** All P0/P1 automated cases executed; every defect logged with live repro + evidence; no defect asserted without a passing (or intentionally-xfail) automated test backing it.

## 7. Reporting
- `reports/ui/` — Playwright/pytest HTML + JUnit XML from the full automated run
- `evidence/screenshots/`, `evidence/api/` — real screenshots and raw JSON-RPC responses captured **during** automated test execution, not staged separately
- `docs/05-execution-summary.md` — final pass/xfail counts and Go/No-Go call
- `docs/04-traceability-matrix.csv` — every user story → test case → automated script → result → defect, so nothing is orphaned
