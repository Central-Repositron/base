# 01 — System Inventory

## Environment
- Base URL: `https://team63.qaaglobal.com`
- Login URL: `https://team63.qaaglobal.com/web/login`
- Dashboard URL (backend, action-372): `https://team63.qaaglobal.com/odoo/action-372`
- Public site: `/` (marketing), `/doctor/list` (doctor directory), `/health_plix/book` (public appointment booking, unauthenticated)
- Application type: **custom Odoo module** (`health_plix`) implementing a Hospital/OPD & IPD Management System for "Shivansh Cancer Center", installed at `/opt/odoo/addons/health_plix/` (path confirmed via a leaked server traceback — see DEF-012).

## Authentication
- Login form: `#login` (text), `#password` (password), submit button "Log in".
- Post-login landing: Hospital Operations Dashboard.
- API auth: standard Odoo JSON-RPC session via `POST /web/login` (form) establishes a `session_id` cookie usable against `POST /web/dataset/call_kw`. The JSON-RPC `/web/session/authenticate` method requires an explicit `db` name that is not exposed/discoverable from the client — use the form-login flow instead (see `03_Automation_Framework/api_client.py`).
- Unauthenticated `call_kw` requests are correctly rejected (`SessionExpiredException`) — access control works.

## Backend Navigation (top bar + "Management" submenu)
| Menu | Odoo Action | Model |
|---|---|---|
| Dashboard | action-372 | — |
| Patients | action-374 | `healthplix.patient` |
| Doctors | action-375 | `healthplix.doctor` |
| Management → Appointments | action-376 | `healthplix.appointment` |
| Management → Prescriptions | action-377 | `healthplix.prescription` |
| Management → Billing | action-383 | `healthplix.billing` |
| Management → IPD Registrations | (not captured) | — |
| Management → Lab Reports | (not captured) | — |
| Management → Ward Management, Bed Management, Treatment Sheets, History & Physical, Progress Sheets, Pre-Op Checklist, Fluid Balance Charts, Lab Test Types, Vital Sign Charts | (not captured) | — |

Model/action IDs above were extracted **live** from the running app via `odoo.__WOWL_DEBUG__.root.env.services.action.currentController.action` and direct DOM inspection of `.o_field_widget[name]` attributes — not guessed from naming convention.

## Dashboard Widgets (confirmed selectors)
- KPI cards: `.hp-stat-card` (5 present) → `.hp-stat-title` / `.hp-stat-value`: **Total Patients, OPD Appointments, Pending Lab Tests, Paid Revenue, Active Doctors**
- Quick Access cards: `.hp-card-name` (9 present): **Patients, Doctors, Prescriptions, Lab Reports, IPD Details, Appointments, Billing, Ward Management, Bed Management**
- Global search box, user avatar menu, header branding

## Key Data Entities — Fields (confirmed via live DOM, not inferred)

**`healthplix.doctor`** (Doctors): `image`, `name`, `specialization`, `experience`, `phone`, `email`, `address`

**`healthplix.patient`** (Patients): `uid` (UHID, e.g. `PAT/00007`), `name`, `phone`, `email`, `referred_by`, `blood_type`, `dob`, `address`, `gender`, `partner_id`, `related_doctor_ids`, `identity_document_type`, `identity_document_number`, `identity_document_attachment(+filename)`, `image`, `prescription_header_ids`

**`healthplix.appointment`** (Appointments): `state` (Draft/Confirmed/Done), `name` (e.g. `APT/0001`), `doctor_id`, `appointment_date`, `appointment_time`, `cost`, `patient_id`, plus a denormalized `patient_*` block (name/photo/phone/email/referred_by/gender/dob/blood_type/address/identity docs), `notes`. Buttons: Confirm, Cancel, Create Billing, Print Receipt, Mark as Done. Server-side constraint confirmed: `_check_double_booking` (blocks same doctor+slot). **No** date-validity or cost-sign constraint exists (see DEF-001, DEF-002).

**`healthplix.billing`** (Billing): `status` (Draft/Invoiced/Partially Paid/Paid), `bill_no`, `patient_id`, `ipd_id`, `invoice_id`, `invoice_amount_total`, `invoice_amount_paid`, `invoice_amount_due`, `total_amount`, `billing_line_ids` (`line_type`: Lab/IPD-Bed/Medicine/Service-Product/Custom-Manual). Buttons: Create Invoice, Reload from Patient, Print Invoice. Invoicing hands off to standard Odoo `account.move`.

**`healthplix.prescription`** (Prescriptions): `Patient`, `Appointment`, `Date` (auto), medicine lines (`Medicine`, `Qty`, `Unit`, `Dosage`, `Duration`, `Notes`), free-text Prescription Notes.

**Lab Report (list view fields)**: Ref, Patient, Date, Test Type, Doctor, Lab, Status.

**IPD Registration (list view fields)**: Reg No, Date, UHID No, IPD No, Patient, Sex, Age, Blood Group, Mobile, Doctor, Registration (+more, not fully captured).

**Ward Management (list view fields)**: Ward Name, Ward Code, Ward Type, Floor, Total Beds.

## Public Booking Form (`/health_plix/book`) — confirmed HTML field IDs
`#doctor_id` (select), `#patient_name`, `#patient_email`, `#patient_phone`, `#gender_male`/`#gender_female`/`#gender_other` (radio, visually hidden behind a styled `<label>`), `#patient_dob`, `#patient_address`, `#appointment_date` (native `<input type=date>`, **no `min` attribute**), `#appointment_time` (native `<input type=time>`), `#appointment_notes`. Page states "OPD Hours: Mon–Sat 9am–6pm | Sun 10am–2pm | Emergency: 24×7" directly above the date/time fields — not enforced (see DEF-002).

## API Surface
Standard Odoo JSON-RPC: `POST /web/dataset/call_kw` with `{model, method, args, kwargs}`. Confirmed reachable and functionally equivalent to the UI's own network calls — every UI action is also directly callable this way with no additional gate, which is why several defects in this pack were verified **twice**: once via the browser UI, once via a raw API call that never touched a browser.

## Risks / Notes
- All monetary/date validation gaps found in the UI were reproduced via direct API call, confirming they live in the model layer, not just missing JavaScript.
- JSON-RPC error responses leak full server tracebacks (internal file paths, addon name) to any caller, authenticated or not (DEF-012).
- Only one internal role (`team63`) was available — role/permission testing (receptionist vs. doctor vs. billing visibility) is unverified (see `defects/enhancements.csv` ENH-005).
- IPD/Ward/Bed/clinical-documentation modules were smoke-tested only (list views render) — not deep-tested this cycle (ENH-006).
