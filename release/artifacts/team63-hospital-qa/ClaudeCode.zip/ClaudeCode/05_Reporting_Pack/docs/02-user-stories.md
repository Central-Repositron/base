# 02 — User Stories

Grounded in verified application behavior (field names, models, workflows confirmed live via UI + direct API — see [01-system-inventory.md](01-system-inventory.md)), not inferred from menu labels alone.

## Authentication
- **US-AUTH-001**: As any hospital staff member, I want to log in with my email/password so I can access the operations dashboard.
- **US-AUTH-002**: As the system, I want invalid credentials rejected and unauthenticated API requests refused so patient/financial data isn't exposed.

## Doctors
- **US-DOC-001**: As an admin, I want to onboard a doctor with name, specialization, experience, and contact details so they can be assigned to appointments.
- **US-DOC-002**: As an admin, I want experience/phone/email fields validated for realistic values so doctor records stay clean and contactable.

## Patients
- **US-PAT-001**: As front-desk staff, I want to register a patient and have a UHID auto-assigned so I can create a valid, trackable medical record.
- **US-PAT-002**: As front-desk staff, I want the system to warn me about a likely-duplicate patient (same phone/email) so one person's history doesn't fragment across multiple records.

## Appointments (Backend)
- **US-APT-001**: As a receptionist, I want to book an OPD appointment with doctor, date, time, and fee so a consultation can be scheduled and billed.
- **US-APT-002**: As the system, I want appointment dates restricted to today-or-future and fees restricted to non-negative values, enforced at the API/model level, so bad data can never reach billing regardless of which client (web, future mobile app, integration) is used.
- **US-APT-003**: As a scheduler, I want the same doctor blocked from being double-booked at the same date/time.

## Public Booking (Unauthenticated Website)
- **US-PUB-001**: As a prospective patient, I want to book a consultation from the public website without creating an account, and receive an accurate confirmation of what actually happened server-side.
- **US-PUB-002**: As the system, I want the public form to enforce the same date/OPD-hours rules as the backend, since it's an unauthenticated write path into clinical data.

## Billing
- **US-BIL-001**: As billing staff, I want a Bill generated from a confirmed Appointment, and an Invoice generated from that Bill, with the amount always matching the source and never negative.

## Dashboard
- **US-DASH-001**: As management, I want the dashboard KPI cards (Total Patients, OPD Appointments, Pending Lab Tests, Paid Revenue, Active Doctors) to always match the real underlying record counts, not just "look populated."

## Platform / API
- **US-SEC-001**: As a security-conscious operator, I want the JSON-RPC API layer to enforce the same validation rules as the UI, reject unauthenticated requests, and never leak internal server details (file paths, stack traces) in error responses.

---

**Coverage note:** IPD Registration, Ward/Bed Management, Prescriptions, and Lab Reports were smoke-tested (list views load, form fields identified — see 01-system-inventory.md) but not deep-tested this cycle; see `defects/enhancements.csv` ENH-006 for the recommended follow-up scope.
