# Shivansh Cancer Center (team63) — QA Reporting Pack

Presentation-ready QA pack for `https://team63.qaaglobal.com`, structured to mirror the standard docs/test-cases/test-data/defects/reports/evidence convention so it's easy to review at a glance. This pack **only reports what was actually executed** — every PASS/FAIL in the CSVs below is backed by a real automated test run or an explicitly-labeled manual verification; nothing here is a template placeholder.

> The fuller, narrative versions of everything here live one level up: [`../01_Test_Strategy.md`](../01_Test_Strategy.md), [`../02_Test_Cases_and_Data.md`](../02_Test_Cases_and_Data.md), [`../03_Automation_Framework/`](../03_Automation_Framework/), [`../04_Bugs_and_Enhancements.md`](../04_Bugs_and_Enhancements.md). This pack condenses them into the CSV/report format for quick presentation. See also [`../06_Comparison_Notes.md`](../06_Comparison_Notes.md) for how this compares to a template-only PostQode-generated pack for the same target.

## Repository Structure

```text
05_Reporting_Pack/
├── README.md                          (this file)
├── docs/
│   ├── 01-system-inventory.md         verified live field/model/selector map
│   ├── 02-user-stories.md             grounded in confirmed behavior, not guessed
│   ├── 03-test-strategy.md            condensed strategy (full version one level up)
│   ├── 04-traceability-matrix.csv     UserStory -> TestCase -> Script -> Result -> Defect
│   ├── 05-execution-summary.md        final real pass/xfail counts + Go/No-Go
│   └── prompt-log.md                  transparency log of the QA process
├── test-cases/test-cases.csv          38 focused cases, real ExecutionStatus per row
├── test-data/ui-test-data.csv         32 data sets, one per meaningful test case
├── defects/
│   ├── defects.csv                    12 real, reproduced defects
│   └── enhancements.csv               7 enhancement recommendations
├── reports/ui/                        Playwright/pytest HTML + JUnit XML from the full run
└── evidence/
    ├── screenshots/                   real screenshots captured during test execution
    └── api/                           raw JSON-RPC request/response evidence
```

## How to Reproduce

```bash
cd ../03_Automation_Framework
python -m pip install -r requirements.txt
python -m playwright install chromium
python -m pytest --junitxml=../05_Reporting_Pack/reports/ui/junit.xml \
                  --html=../05_Reporting_Pack/reports/ui/report.html --self-contained-html
```

This regenerates `reports/ui/` and re-populates `evidence/screenshots/` + `evidence/api/` with fresh evidence from a live run (test data is timestamp-suffixed, so repeated runs against the shared QA database never collide).

## Headline Finding

**DEF-001 (Critical):** a negative Consultation Fee on an Appointment flows with zero validation through Confirm → Create Billing → Create Invoice, producing a real negative Customer Invoice in Odoo Accounting — confirmed twice, once via the browser UI and once via a raw JSON-RPC API call that never touched a browser, proving the gap is in the server-side model, not just missing front-end JavaScript.

See `defects/defects.csv` for all 12 defects and `docs/05-execution-summary.md` for the full run summary.

## What's Genuinely Verified vs. Not Yet Run

Every row in `test-cases/test-cases.csv` has an honest `ExecutionStatus`: `PASS`, `FAIL` (with a `DefectID`), or `NOT_RUN`. `NOT_RUN` rows are real gaps (role-based access control — only one account was available; the positive-fee Billing/Invoice path; near-duplicate patient detection) explicitly called out rather than hidden, so the next QA cycle knows exactly where to start.
