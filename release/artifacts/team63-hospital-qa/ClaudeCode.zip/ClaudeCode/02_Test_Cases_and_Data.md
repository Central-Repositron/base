# Test Cases & Test Data — Shivansh Cancer Center

Companion to [01_Test_Strategy.md](01_Test_Strategy.md). All cases below were designed against the live QA build at https://team63.qaaglobal.com; cases marked **FAIL** were actually executed during this engagement and reproduce a logged defect (see `04_Bugs_and_Enhancements.md` for the matching BUG-ID). Cases marked **PASS** were also executed. Cases marked **Not Run** are written and ready for the automation suite / next execution pass but were not manually run in this session due to time-boxing.

Priority: **P0** blocker/critical path, **P1** high, **P2** medium, **P3** low/cosmetic.

---

## Test Data Sets

| Data Set | Field | Value |
|---|---|---|
| **TD-01 Valid Doctor** | Name | `Dr. Anjali Mehta` |
| | Specialization | `Medical Oncology` |
| | Experience (Years) | `12` |
| | Phone | `9876543210` |
| | Email | `anjali.mehta@shivansh-test.com` |
| **TD-02 Invalid Doctor (boundary)** | Experience (Years) | `-5` |
| | Phone | `abcd123` |
| | Email | `not-an-email` |
| **TD-03 Valid Patient** | Name | `QA Patient One` |
| | Phone | `9123456780` |
| | Email | `qa.patient1@shivansh-test.com` |
| | Gender | `Female` |
| | DOB | `1990-05-15` |
| | Blood Type | `O+` |
| **TD-04 Valid Appointment** | Doctor | TD-01 |
| | Patient | TD-03 |
| | Date | Today + 3 days |
| | Time | `10:30` |
| | Consultation Fee | `500.00` |
| **TD-05 Invalid Appointment (boundary)** | Date | `01/01/2024` (past) |
| | Time | `99:99` (invalid) |
| | Consultation Fee | `-500.00` (negative) |
| **TD-06 Public Booking (valid)** | Full Name | `Public QA Tester` |
| | Email | `publicqa@test.com` |
| | Mobile | `9999999999` |
| | Appointment Date | Today + 5 days |
| | Preferred Time | `11:00` |
| **TD-07 Public Booking (invalid/boundary)** | Appointment Date | `01/01/2020` (past) |
| | Preferred Time | `03:00` (outside OPD hours 9am–6pm) |
| | Mobile | `99999999999999999999` (20 digits) |
| **TD-08 Prescription** | Medicine Qty | `2` |
| | Dosage | `1 tablet twice daily` |
| | Duration | `5 days` |

---

## 1. Authentication

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-AUTH-01 | Login with valid credentials | P0 | 1. Navigate to `/odoo/action-372` (redirects to login). 2. Enter `team63` / valid password. 3. Click Log in. | User is redirected to the Hospital Operations Dashboard; user avatar visible top-right. | **PASS** |
| TC-AUTH-02 | Login with invalid password | P0 | 1. Enter valid username, wrong password. 2. Click Log in. | Generic error shown; no session created; no indication of which field was wrong (username vs password) for security. | Not Run |
| TC-AUTH-03 | Login with empty fields | P1 | 1. Leave both fields blank. 2. Click Log in. | Client-side validation blocks submit / server returns error. | Not Run |
| TC-AUTH-04 | Reset Password link | P2 | 1. On login page, click "Reset Password". | User routed to password-reset flow, redirect param preserves target action (`/web/reset_password?redirect=...action-372`). | Not Run |
| TC-AUTH-05 | Direct deep-link to `/odoo/action-372` when unauthenticated | P1 | 1. Log out / open incognito. 2. Navigate directly to the action URL. | Redirected to login; after login, returned to the originally requested action. | Not Run |
| TC-AUTH-06 | Session persists across module navigation | P2 | 1. Log in. 2. Navigate across Patients / Doctors / Management submenus for several minutes. | No unexpected re-prompt for login. | **PASS** (observed during exploration) |

## 2. Doctors Module

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-DOC-01 | Create doctor with valid data | P0 | 1. Doctors → New. 2. Fill TD-01. 3. Save/navigate away. | Doctor record saved; appears in Doctors list with correct columns. | **PASS** |
| TC-DOC-02 | Experience accepts negative value | P1 | 1. Create/edit doctor. 2. Set Experience (Years) = `-5`. 3. Save. | **Expected:** field rejects negative input or shows validation error. | **FAIL** — saved silently, list shows `-5`. See BUG-03. |
| TC-DOC-03 | Phone field rejects non-numeric input | P1 | 1. Set Phone = `abcd123`. 2. Save. | **Expected:** rejected or auto-formatted. | **FAIL** — saved as literal text `abcd123`. See BUG-04. |
| TC-DOC-04 | Email field rejects invalid format | P1 | 1. Set Email = `not-an-email`. 2. Save. | **Expected:** inline validation error, save blocked. | **FAIL** — saved with no error. See BUG-05. |
| TC-DOC-05 | Mandatory Name field enforced | P2 | 1. Create doctor. 2. Leave Name blank. 3. Attempt save. | Save blocked with "required field" indication. | Not Run |
| TC-DOC-06 | Doctor list search/filter | P2 | 1. In Doctors list, search by name substring. | Matching doctor(s) shown; non-matches hidden. | Not Run |
| TC-DOC-07 | Doctor appears in Appointment "Doctor" dropdown after creation | P1 | 1. Create a new doctor. 2. Go to Appointments → New → Doctor field. | Newly created doctor is selectable immediately (no cache lag). | **PASS** |
| TC-DOC-08 | Doctor appears in public booking "Preferred Specialist" dropdown | P1 | 1. Create doctor in backend. 2. Open `/health_plix/book` (fresh session). | Doctor listed as a bookable specialist. | **PASS** |

## 3. Patients Module

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-PAT-01 | Create patient with only Name (no other fields) | P1 | 1. Patients → New. 2. Enter Name only. 3. Navigate away (autosave). | **Observed:** record autosaves as `PAT/000xx` despite a transient "Missing required fields" toast; unclear which field is actually mandatory. | **FAIL (UX)** — see BUG-09; behavior is inconsistent/confusing. |
| TC-PAT-02 | Create patient with full valid data | P0 | 1. Patients → New. 2. Fill TD-03 (all fields). 3. Save. | Patient saved with UHID auto-generated (`PAT/xxxxx`), Customer partner auto-linked. | **PASS** |
| TC-PAT-03 | UHID sequence is contiguous / no gaps | P2 | 1. Create 3 patients in sequence, noting UHID each time. | UHIDs increment by exactly 1 each time. | **FAIL** — first observed UHID was `PAT/00002`, not `PAT/00001`, on the very first record created in a clean session (sequence appears to advance even on discarded "New" forms). See BUG-10. |
| TC-PAT-04 | Patient tabs (Prescriptions/Lab Reports/IPD/Appointments/Billings/Treatment Plans) render and are empty for a new patient | P2 | 1. Open a freshly created patient. 2. Check each tab. | Each tab loads without error and shows an empty list. | **PASS** |
| TC-PAT-05 | "Create Cancer Treatment Plan" button | P2 | 1. Open a patient. 2. Click "Create Cancer Treatment Plan". | A treatment plan wizard/record opens correctly. | Not Run |
| TC-PAT-06 | Photo/ID Document upload | P2 | 1. Open patient. 2. Upload an image via Photo and ID Document fields. | File uploads and previews correctly; Attachment Filename populates. | Not Run |
| TC-PAT-07 | Duplicate patient detection by phone/email | P1 | 1. Create patient A with phone `9123456780`. 2. Create patient B with the same phone. | **Expected:** warning or merge suggestion. | Not Run — recommend as a dedicated exploratory charter; likely gap given other validation gaps found. |

## 4. Appointments (Backend)

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-APT-01 | Create appointment with valid data (TD-04) | P0 | 1. Appointments → New. 2. Select Doctor, Patient. 3. Set future Date, valid Time, positive Fee. 4. Save. | Appointment saved in **Draft**, `Appointment No` auto-generated `APT/000x`. | **PASS** |
| TC-APT-02 | Date field is mandatory | P1 | 1. New appointment. 2. Leave Date blank. 3. Attempt to proceed. | Field highlighted red / "Missing required fields" until filled. | **PASS** (field correctly highlighted red until a date is entered) |
| TC-APT-03 | Date field accepts past dates | P0 | 1. New appointment. 2. Set Date = `01/01/2024`. 3. Save. | **Expected:** rejected — an OPD appointment cannot be scheduled in the past. | **FAIL** — accepted and saved with no warning. See BUG-02. |
| TC-APT-04 | Time field rejects out-of-range input | P2 | 1. Set Time = `99:99`. 2. Move focus away. | **Expected:** validation error shown. | **PARTIAL FAIL** — invalid value is silently discarded and reset to `00:00:00`, but **no error message is shown**, so the user isn't told their input was rejected. See BUG-08. |
| TC-APT-05 | Consultation Fee accepts negative values | P0 | 1. Set Consultation Fee = `-500.00`. 2. Click **Confirm**. | **Expected:** rejected before status can move to Confirmed. | **FAIL — Critical.** Status moved Draft → Confirmed with fee `-500.00` persisted. See BUG-01. |
| TC-APT-06 | Confirm transitions status Draft → Confirmed | P0 | 1. Fill valid appointment. 2. Click Confirm. | Status bar highlights "Confirmed"; Confirm/Cancel buttons replaced appropriately. | **PASS** (mechanically works; see TC-APT-05 for the data-integrity failure riding along with it) |
| TC-APT-07 | Create Billing from a Confirmed appointment | P0 | 1. Confirm an appointment. 2. Click "Create Billing". | A new `BILL/xxxxx` record is created, pre-filled with a billing line = Consultation Fee. | **PASS** (mechanically) — **FAIL (data)** when fee is negative, see TC-APT-05/BILL-02. |
| TC-APT-08 | Mark as Done | P1 | 1. On a Confirmed appointment, click "Mark as Done". | Status moves to "Done"; record becomes read-only/archived per business rule (verify). | Not Run |
| TC-APT-09 | Cancel appointment | P1 | 1. On a Draft appointment, click Cancel. | Appointment marked cancelled; excluded from active dashboard counters. | Not Run |
| TC-APT-10 | Print Receipt | P2 | 1. On a Confirmed appointment, click "Print Receipt". | PDF/preview generated with correct patient, doctor, date, fee. | Not Run |
| TC-APT-11 | Patient Info section auto-fills from selected Patient | P1 | 1. Select an existing Patient in a new Appointment. | Patient Name, Phone, Email, Gender, DOB, Blood Type, Address auto-populate from the Patient record. | **PASS** |
| TC-APT-12 | Dashboard "OPD Appointments" counter updates | P2 | 1. Note counter value. 2. Create + Confirm a new appointment. 3. Return to Dashboard. | Counter increments by 1. | **PASS** |

## 5. Public Appointment Booking (`/health_plix/book`)

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-PUB-01 | Submit booking with all required fields valid (TD-06) | P0 | 1. Open `/health_plix/book`. 2. Choose doctor. 3. Fill patient info. 4. Choose future date/time within OPD hours. 5. Confirm Appointment. | "Appointment Confirmed!" page shown with a `Ref # APT/000x`; record exists in backend Appointments (status likely Confirmed) and a Patient record is created/matched. | **PASS** |
| TC-PUB-02 | Required-field client-side validation | P1 | 1. Leave Full Name blank. 2. Click Confirm Appointment. | Browser-native validation stops submission and focuses the empty field. | **PASS** |
| TC-PUB-03 | Booking with a past date is accepted | P0 | 1. Fill form with Appointment Date = `01/01/2020`. 2. Submit. | **Expected:** rejected with a clear error ("please choose a future date"). | **FAIL — Critical.** Booking confirmed as `APT/0002`; visible on backend Dashboard (Total Patients/OPD Appointments incremented). See BUG-02. |
| TC-PUB-04 | Booking outside stated OPD hours is accepted | P0 | 1. Fill form with Preferred Time = `03:00` (page states OPD hours are 9am–6pm Mon–Sat / 10am–2pm Sun). 2. Submit. | **Expected:** rejected, or routed to "Emergency" flow with distinct messaging. | **FAIL.** Accepted silently as a normal OPD booking. Same defect instance as TC-PUB-03. See BUG-02. |
| TC-PUB-05 | Mobile Number field has no length limit | P2 | 1. Enter a 20-digit numeric string in Mobile Number. 2. Submit. | **Expected:** field enforces a reasonable max length (e.g., 10–15 digits) client-side. | **FAIL** — accepted with no truncation/error. See BUG-06. |
| TC-PUB-06 | Booking creates a new Patient when email doesn't match an existing one | P1 | 1. Submit booking with a brand-new email. | New `PAT/xxxxx` created, linked to the new Appointment. | **PASS** (Dashboard "Total Patients" incremented from 1 → 2 after this booking) |
| TC-PUB-07 | Booking with an existing patient's email doesn't create a duplicate | P1 | 1. Submit a second booking reusing an email from TC-PUB-06. | **Expected:** matched to existing Patient, not duplicated. | Not Run — recommend priority follow-up given TC-PAT-07 gap. |
| TC-PUB-08 | Doctor dropdown only lists active doctors | P2 | 1. Compare dropdown contents to Doctors list in backend. | Matches active doctor roster. | Not Run |
| TC-PUB-09 | Confirmation page displays correct summary | P1 | 1. Complete a booking. 2. Review confirmation page fields (Doctor, Patient, Date, Time). | All fields match what was submitted. | **PASS** |
| TC-PUB-10 | Back button between steps preserves entered data | P2 | 1. Fill Step 1–2. 2. Go to Step 3. 3. Click "← Back". | Previously entered data is retained, not cleared. | Not Run |
| TC-PUB-11 | Backend Appointment status matches the public confirmation wording | P1 | 1. Complete a public booking (TC-PUB-01). 2. Immediately check the same appointment in the backend Appointments list. | If the public page says "Appointment Confirmed!", the backend record's Status should be **Confirmed**. | **FAIL.** Public page said "Appointment Confirmed!" but the backend record (`APT/0002`) was left in **Draft** status with Fee `0.00`. Confusing for staff (who see it as unconfirmed/actionable) and misleading for patients (who believe it's confirmed). See BUG-12. |

## 6. Billing & Invoicing

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-BILL-01 | Create Billing produces correct positive total | P0 | 1. Confirm an appointment with a valid positive fee (e.g., 500.00). 2. Create Billing. | Bill's "Total Amount" and billing line subtotal both equal the fee. | Not Run (only the negative-fee path was executed this pass) |
| TC-BILL-02 | Negative appointment fee propagates to Billing total | P0 | 1. Follow TC-APT-05 (negative fee, Confirmed). 2. Create Billing. | **Expected:** blocked, or fee floored at 0 with a warning. | **FAIL — Critical.** Bill `BILL/00001` created with Total Amount `-500.00`, status "Invoiced"; also skews the Billing list's aggregate footer total. See BUG-01. |
| TC-BILL-03 | Create Invoice from Billing | P0 | 1. On a Bill in Draft, click "Create Invoice". | A standard Odoo Customer Invoice (`INV/YYYY/xxxxx`) is generated in Draft, correctly totaled, linked back to the Bill. | **PASS (mechanically)** — **FAIL (data)** when source fee is negative: invoice created with Total `$-500.00` / Amount Due `$-500.00`. Not posted (left in Draft deliberately to avoid creating a real negative ledger entry). See BUG-01. |
| TC-BILL-04 | Billing status lifecycle Draft → Invoiced → Partially Paid → Paid | P1 | 1. Create Bill. 2. Create Invoice. 3. Record a partial payment in Accounting. 4. Record remaining payment. | Status bar advances correctly at each step. | Not Run |
| TC-BILL-05 | "Reload from Patient" button | P2 | 1. On a Bill, click "Reload from Patient". | Billing lines refresh from the patient's outstanding chargeable items (labs, IPD, meds) without duplicating existing lines. | Not Run |
| TC-BILL-06 | Manually add a Billing Line (Custom/Manual type) | P2 | 1. On a Bill, "Add a line". 2. Choose Line Type = Custom/Manual. 3. Enter description, qty, unit price. | Line adds to Billing Lines and Total Amount recalculates. | Not Run |
| TC-BILL-07 | Print Invoice | P2 | 1. On an Invoiced bill, click "Print Invoice". | PDF generated with correct patient/line-item/total data. | Not Run |
| TC-BILL-08 | Billing list aggregate footer sums correctly | P2 | 1. Create 2+ bills with known amounts. 2. Open Billing list view. | Footer total = sum of all "Total Amount" values, including correctly handling any negative entries (once BUG-01 is fixed, this should never occur in practice). | **PASS (mechanically correct math)** — footer showed `-500.00` matching the single (buggy) record; confirms the aggregate itself computes correctly, it's just summing bad data. |

## 7. Prescriptions

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-RX-01 | Create prescription linked to patient + appointment | P1 | 1. Prescriptions → New. 2. Select Patient, Appointment. 3. Add a medicine line (TD-08). 4. Save. | Prescription saves with auto Date, correct linkage, "Print Prescription" becomes usable. | Not Run |
| TC-RX-02 | Medicine line Quantity accepts 0 or negative | P2 | 1. Add medicine line. 2. Set Qty = `0` or `-1`. | **Expected:** rejected (a prescription can't have zero/negative units). | Not Run — flagged as **likely fail** given the pattern of numeric-field validation gaps found elsewhere (Experience, Fee). Recommend as first automated regression case once framework is extended. |
| TC-RX-03 | Print Prescription | P2 | 1. On a saved prescription, click "Print Prescription". | Formatted prescription PDF/preview opens with patient, doctor, medicines, dosage, duration. | Not Run |
| TC-RX-04 | Prescription visible under Patient's "Prescriptions" tab | P1 | 1. Create a prescription for a patient. 2. Open that Patient record → Prescriptions tab. | New prescription listed with correct Ref/Date/Appointment. | Not Run |

## 8. Lab Reports

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-LAB-01 | Create lab report with valid data | P1 | 1. Lab Reports → New. 2. Fill Patient, Date, Test Type, Doctor, Lab. 3. Save. | Record saves; Status defaults sensibly (e.g., "Pending"). | Not Run |
| TC-LAB-02 | Lab Report status affects Dashboard "Pending Lab Tests" counter | P2 | 1. Note counter. 2. Create a lab report in a "pending" state. 3. Return to Dashboard. | Counter increments by 1. | Not Run |
| TC-LAB-03 | Update Lab Report result / mark completed | P1 | 1. Open an existing lab report. 2. Enter result values, mark Completed. | Status updates; record no longer counted in "Pending Lab Tests". | Not Run |
| TC-LAB-04 | Lab Test Types master data drives Test Type dropdown | P2 | 1. Add a new entry under Management → Lab Test Types. 2. Create a new Lab Report. | New test type is selectable. | Not Run |

## 9. IPD / Ward Management (Smoke)

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-IPD-01 | IPD Registrations list loads with expected columns | P2 | 1. Management → IPD Registrations. | Columns render: Reg No, Date, UHID No, IPD No, Patient, Sex, Age, Blood Group, Mobile, Doctor, Registration (+ more, scrollable). | **PASS** |
| TC-IPD-02 | Create an IPD Registration | P1 | 1. IPD Registrations → New. 2. Fill patient + admission details. 3. Save. | Record saves with auto IPD No.; reflected under linked Patient's "IPD Details" tab. | Not Run |
| TC-WARD-01 | Ward Management list loads with expected columns | P3 | 1. Management → Ward Management. | Columns render: Ward Name, Ward Code, Ward Type, Floor, Total Beds. | **PASS** |
| TC-WARD-02 | Create a Ward and verify Total Beds vs. Bed Management consistency | P2 | 1. Create a Ward with Total Beds = 10. 2. Go to Bed Management. 3. Verify bed count/records align. | Bed Management reflects the ward's declared capacity (either auto-generated beds or a consistency check). | Not Run |

## 10. Cross-Cutting / Non-Functional Smoke

| ID | Title | Priority | Steps | Expected Result | Actual / Status |
|---|---|---|---|---|---|
| TC-NFR-01 | List views show a loading indicator during navigation | P3 | 1. Navigate between several Management submenu items in quick succession. | A spinner/skeleton is shown while data loads; view never appears fully blank. | **FAIL (minor)** — Doctors and IPD Registrations list views briefly rendered a completely blank page (~1s) with no loading indicator before populating. See BUG-11. |
| TC-NFR-02 | Save/error toast identifies the specific field at fault | P2 | 1. Trigger a "Missing required fields" toast (e.g., new Patient/Appointment with fields empty). | Toast or inline marker clearly names the specific field. | **FAIL** — generic message only; on the Patient form the record went on to save regardless. See BUG-09. |
| TC-NFR-03 | Currency/amount fields never display without validation guard | P0 | (Composite of TC-APT-05 / TC-BILL-02) | No monetary field anywhere in the Patient→Appointment→Billing→Invoice chain accepts negative values. | **FAIL** — see BUG-01. |
