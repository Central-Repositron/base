# Comparison: This QA Pack vs. the PostQode-Generated Pack

Reviewed: `C:\Users\sayan\Documents\SUV\Competition\PostQode\team63-hospital-qa.zip` (extracted to `team63-hospital-qa-extracted/`), same target (`team63.qaaglobal.com`), produced via the `cg.txt` playbook.

## Bottom line

The PostQode pack is a **well-organized scaffold**, not a completed QA pass. Its own `docs/05-execution-summary.md` says so directly: **4 test cases executed** (all visibility checks — "does this element render"), **0 defects found**, and `defects/defects.csv` / `defects/enhancements.csv` contain literally 2 and 3 rows respectively, each explicitly labeled `"Template sample row"`. Nothing in that pack was actually broken by testing.

This session's work found and reproduced **12 real defects live** on the same instance, including one Critical (a negative fee reaching a real negative invoice) confirmed two independent ways — through the browser and through a raw API call. That's the core difference: PostQode built the container; the testing that was supposed to go in it never ran.

## What PostQode's structure got right (adopted here)

1. **Presentation convention** — `docs/`, `test-cases/`, `test-data/`, `defects/`, `reports/{ui,api}`, `evidence/{screenshots,traces,videos}`, a numbered doc sequence, and a `prompt-log.md` for transparency. All mirrored in [`05_Reporting_Pack/`](05_Reporting_Pack/), populated with real data instead of templates.
2. **CSV schemas** — `Defect_ID,Module,Title,Severity,Priority,Environment,Preconditions,Steps_to_Reproduce,Expected_Result,Actual_Result,Evidence_Path,Status,Owner,Created_On,Retest_On,Comments` and the matching `test-cases.csv`/`enhancements.csv` schemas are genuinely good, judge-legible formats. Reused verbatim.
3. **Real CSS selectors for the Dashboard** — `.hp-stat-card` / `.hp-stat-title` / `.hp-stat-value` / `.hp-card-name` were confirmed live (5 KPI cards, 9 quick-access cards) and are more robust than the text/role locators used elsewhere in this session's original framework. **This closed a genuine gap**: the original `03_Automation_Framework` had zero Dashboard-page automated coverage. Added `pages/dashboard_page.py` + `tests/test_dashboard.py` (4 tests, all passing), including a real KPI-vs-actual-data integrity check (`Total Patients` KPI cross-checked against `search_count` via the API) — a step beyond PostQode's own "is it visible" version of the same idea.
4. **A dedicated API-testing layer** (`tests/api/session.api.spec.ts` in their pack, hitting `/web/session/authenticate` + `/web/webclient/load_menus`) — this was a real gap in the original delivery, which was 100% browser-driven UI automation. Building `api_client.py` + `tests/test_api_direct_validation.py` on this idea turned out to be the single highest-value addition of this pass: it **proved DEF-001 and DEF-002 are server-side model gaps**, not just missing client-side JavaScript, by reproducing both via a raw JSON-RPC `call_kw` request that never touched a browser. It also surfaced a defect PostQode's own API smoke test would never have caught: **DEF-012**, verbose Python stack traces (internal file paths, addon name) leaked in every JSON-RPC error response, including to unauthenticated callers.
5. **Release-readiness levels (Green/Amber/Red)** and an explicit **defect workflow** (New → Triaged → Assigned → Fixed → Retest → Closed) — good presentation devices for a judge/stakeholder audience, reflected in `docs/05-execution-summary.md`'s Go/No-Go call.
6. **Their planned-but-never-executed `BIL-003 "Prevent negative or zero invalid amount"`** is exactly the case that turned into this pass's headline Critical defect (DEF-001). Worth noting: their plan correctly identified the risk; only the execution was missing.

## What's genuinely concerning in the PostQode pack (flagged, not adopted)

1. **Hardcoded password in committed source files.** `tests/ui/edge-cases.spec.ts` and `tests/api/session.api.spec.ts` both contain `process.env.QA_PWD || 'DLVxepJau1'` — a literal fallback password baked directly into tracked TypeScript files, despite `cg.txt`'s own explicit instruction: *"Do not hard-code the password into Playwright scripts... Never hard-code secrets."* If that ZIP is submitted or shared as-is, the credential ships with it. **Fix before submitting**: remove the fallback, make the env var required (`process.env.QA_PWD!` or throw if unset).
2. **Defects/enhancements presented as a deliverable but are template placeholders.** This isn't a structural flaw — it's a completeness flaw. If presenting this pack, be explicit that the defect log is unpopulated rather than implying testing occurred.
3. **Shallow test depth where it did run.** The 4 executed tests check that elements *exist* (search box accepts a long string and doesn't crash, KPI cards show a parseable number) — none of them create, mutate, or boundary-test real data. `edge-cases.spec.ts`'s "edge case" testing is limited to the dashboard search box, not any actual business field.

## What this session's original pass had NOT covered (before this comparison)

- Dashboard KPI/nav/quick-access automated coverage — **added** (`test_dashboard.py`).
- Any API-layer testing at all — **added** (`api_client.py`, `test_api_direct_validation.py`), and it's now the strongest evidence in the whole bug list.
- A judge-presentable CSV/traceability-matrix reporting format — **added** (`05_Reporting_Pack/`).

## What's still a gap in both packs (neither closed it)

- **Role-based access control** — both packs only had one account (`team63`) available; PostQode's `test-cases.csv` SEC-001 and this pack's `TC-SEC-02` both list it `NOT_RUN` for the same reason.
- **IPD/Ward/Bed/clinical-documentation depth** — both packs smoke-tested these modules at most (list views render) and flagged deeper testing as follow-up work.
- **Notification/email delivery verification** — the public booking page's "we'll email you within 2 hours" promise is unverified in both.

## Cherry-picked from `cg.txt` specifically

Kept: the four-agent mental model (discovery → strategy → build → API) as a sequencing idea, the P0/P1/P2 risk table (bed double-allocation, discharge/bed-release, overlapping appointments, KPI/dashboard-sync, duplicate patient — most already covered or explicitly flagged `NOT_RUN` in `05_Reporting_Pack/test-cases/test-cases.csv`), the `xfail`-until-fixed regression pattern's spiritual cousin (`cg.txt` doesn't specify this mechanism but shares the goal — "don't claim execution that didn't happen"), and the safety constraints (no destructive/load/exploit testing) — already the practice followed throughout.

Not kept: the literal PostQode/TypeScript toolchain (this session's framework is Playwright **Python**, already built, verified, and working — rewriting it in TypeScript would add risk for zero benefit), and the "don't throw the whole assignment into one prompt" phasing advice, which is moot in an agentic session that can just verify each layer live as it goes rather than batching manual copy-paste prompts.
